#!/usr/bin/env node
/** C01 live functional + capture worker. Writes only under .cache/combat-c01-2026-10-10
 * and docs/baselines/combat-c01-2026-10-10. One 1280x720 DPR1 game context. */
import {chromium} from 'playwright';
import fs from 'node:fs/promises';
import path from 'node:path';
import {captureSurface, appendFrame, writeCaptureManifest} from '../../scripts/lib/capture-manifest.mjs';
import {browserOwnership} from '../../scripts/lib/browser-ownership.mjs';

const ROOT = path.resolve(import.meta.dirname, '../..');
const CACHE = path.join(ROOT, '.cache/combat-c01-2026-10-10');
const BASE = path.join(ROOT, 'docs/baselines/combat-c01-2026-10-10');
const CDP_PORT = Number(process.env.ASHEN_CDP_PORT || 10137);
const GAME_URL = process.env.ASHEN_URL || 'http://127.0.0.1:5973/ashen-reach.html?dev&play';
const phase = process.argv.includes('--capture') ? 'capture' : process.argv.includes('--functional') ? 'functional' : 'all';

const compactActorSrc = () => {
  const a = globalThis.ASHEN;
  if (!a) return {missing: true};
  const p = a.player, c = a.combat, debug = p?.getDebugState?.() || {};
  const expl = c?.exploration?.snapshot?.();
  const obj = c?.objective?.snapshot?.();
  const enemies = (c?.enemies || []).slice(0, 8).map(e => ({
    id: e.id, name: e.name, state: e.state, hp: +e.hp?.toFixed?.(2) || e.hp, hpMax: e.hpMax,
    hostile: e.hostile, hidden: e.hidden, lockedState: !!e.lockedState,
    diagnosticFloorY: e.diagnosticFloorY ?? null,
    x: +e.position.x.toFixed(3), y: +e.position.y.toFixed(3), z: +e.position.z.toFixed(3),
  }));
  const los = (id) => {
    const t = c?.enemies?.find(e => e.id === id) || (c?.dummy?.id === id ? c.dummy : null);
    if (!t || !c?.lineOfSight) return null;
    const r = c.lineOfSight(t);
    return {clear: !!r.clear, obstacle: r.obstacle || null};
  };
  return {
    ready: !!a.ready, playableReady: !!a.playableReady, combatReady: !!a.combatReady,
    navigationReady: !!a.navigationReady, regionReady: !!a.regionReady, hostilesReady: !!a.hostilesReady,
    playableMs: a.playableMs ?? null, navigationMs: a.navigationMs ?? null,
    loadMs: a.loadMs ?? null, regionMs: a.regionMs ?? null,
    gpu: {depthBundle: a.gpu?.depthBundle, errors: a.gpu?.errors?.slice?.() || [], frames: a.gpu?.frames ?? null},
    backgroundError: a.backgroundError || null,
    player: p ? {
      x: +p.body.position.x.toFixed(3), y: +p.body.position.y.toFixed(3), z: +p.body.position.z.toFixed(3),
      facing: +p.getFacing().toFixed(4), grounded: !!p.getGrounded(), flying: !!p.isFlying?.(),
      usingPhysics: !!debug.usingPhysics, recoveries: debug.recoveries ?? null,
      phase: a.body?.getState?.()?.phase ?? null,
    } : null,
    rig: a.rig ? {yaw: +a.rig.yaw.toFixed(4), pitch: +a.rig.pitch.toFixed(4), distance: +a.rig.distance.toFixed(3)} : null,
    dev: {god: !!a.dev?.god, flying: !!a.dev?.flying, enabled: !!a.dev?.enabled},
    menuOpen: !!a.menu?.isOpen,
    scenario: c?.scenarios?.active ?? null,
    scenarioList: c?.scenarios?.list?.map(s => ({id: s.id, name: s.name})) ?? null,
    trace: c?.trace ? {size: c.trace.size, dropped: c.trace.dropped} : null,
    life: c?.life ? {hp: +c.life.hp.toFixed(3), hpMax: c.life.hpMax, dead: !!c.life.dead, inCombat: !!c.life.inCombat, time: +c.life.time.toFixed(3)} : null,
    progress: c?.progress ? {level: c.progress.level, xp: c.progress.xp, mana: +c.progress.mana.toFixed(3), manaMax: c.progress.manaMax} : null,
    dummy: c?.dummy ? {id: c.dummy.id, hp: +c.dummy.hp.toFixed(2), hpMax: c.dummy.hpMax, x: +c.dummy.position.x.toFixed(3), y: +c.dummy.position.y.toFixed(3), z: +c.dummy.position.z.toFixed(3), state: c.dummy.state} : null,
    enemyCount: c?.enemies?.length ?? 0,
    enemies,
    target: c?.targeting?.current?.id ?? c?.snapshot?.().target ?? null,
    pendingSpell: c?.pendingSpell ?? null,
    spells: c ? {
      fire: {casts: c.spell?.casts ?? null, cooldown: c.spell?.cooldown ?? null},
      lava: {casts: c.lava?.casts ?? null, cooldown: c.lava?.cooldown ?? null},
      pyre: {casts: c.pulse?.casts ?? null, cooldown: c.pulse?.cooldown ?? null},
    } : null,
    audio: c?.audio?.status ? {error: c.audio.status.error || null, initializing: !!c.audio.status.initializing, muted: !!c.audio.muted} : null,
    exploration: expl ? {phase: expl.record?.phase, sessionOnly: !!expl.sessionOnly, candidate: expl.candidate, discovered: expl.record?.discovered?.length ?? null} : null,
    objective: obj ? {phase: obj.phase, remaining: obj.remaining?.length ?? null} : null,
    losDummy: c?.dummy ? (c.lineOfSight(c.dummy) && {clear: !!c.lineOfSight(c.dummy).clear, obstacle: c.lineOfSight(c.dummy).obstacle || null}) : null,
    losEnemies: Object.fromEntries((c?.enemies || []).slice(0, 3).map(e => [e.id, los(e.id)])),
  };
};

async function writeJson(file, data) {
  await fs.mkdir(path.dirname(file), {recursive: true});
  await fs.writeFile(file, JSON.stringify(data, null, 2) + '\n');
}

async function openDev(page) {
  if (await page.locator('#game-menu').isVisible()) {
    const devPane = page.locator('.game-menu-developer, [data-pane="developer"]');
    if (await page.getByLabel('Combat rehearsal', {exact: true}).count()) return;
    if (await page.getByRole('button', {name: 'Developer tools', exact: true}).count()) {
      await page.getByRole('button', {name: 'Developer tools', exact: true}).click();
      return;
    }
  }
  await page.keyboard.press('Escape');
  await page.waitForTimeout(200);
  if (!await page.locator('#game-menu').isVisible()) {
    await page.keyboard.press('Escape');
    await page.waitForTimeout(250);
  }
  await page.getByRole('button', {name: 'Developer tools', exact: true}).click();
  await page.getByLabel('Combat rehearsal', {exact: true}).waitFor({timeout: 8000});
}

async function focusCanvas(page) {
  const canvas = page.locator('canvas').first();
  await canvas.click({position: {x: 640, y: 360}, force: true}).catch(() => {});
  await page.waitForTimeout(80);
}

const sleep = (page, ms) => page.waitForTimeout(ms);

async function main() {
  const errors = [];
  const findings = [];
  const started = new Date().toISOString();
  await fs.mkdir(path.join(CACHE, 'stills'), {recursive: true});
  await fs.mkdir(path.join(CACHE, 'trace'), {recursive: true});
  await fs.mkdir(path.join(CACHE, 'capture/frames'), {recursive: true});
  await fs.mkdir(BASE, {recursive: true});

  const browser = await chromium.connectOverCDP(`http://127.0.0.1:${CDP_PORT}`);
  const existing = browser.contexts().flatMap(c => c.pages()).map(p => p.url());
  const blankOk = existing.every(u => u === 'about:blank' || u === 'about:blank/');
  const ownership = await browserOwnership(browser, {
    cdpPort: CDP_PORT, url: GAME_URL,
    purpose: 'C01 functional scenarios + combat capture; no FPS claim; contention unknown',
    renderingClients: 1,
  });
  ownership.owner = 'grok-c01';
  ownership.slot = 8;
  ownership.existingPages = existing;
  ownership.blankHarness = blankOk;
  ownership.vitePort = 5973;
  await writeJson(path.join(CACHE, 'ownership.json'), ownership);
  await writeJson(path.join(BASE, 'ownership.json'), ownership);
  if (!blankOk) findings.push({level: 'fail', msg: `Harness pages not blank: ${existing.join(', ')}`});

  const context = await browser.newContext({
    viewport: {width: 1280, height: 720},
    deviceScaleFactor: 1,
    acceptDownloads: true,
  });
  const page = await context.newPage();
  page.on('pageerror', e => errors.push({kind: 'pageerror', message: e.message}));
  page.on('console', m => {
    if (m.type() === 'error') errors.push({kind: 'console', message: m.text()});
  });
  let cdp;
  const report = {started, phase, source: 'd7dce455b36cbd6d809d12a0533b0947364ebe81', url: GAME_URL, ownership, errors, findings};

  try {
    const wall0 = Date.now();
    await page.goto(GAME_URL, {waitUntil: 'commit'});
    const commitMs = Date.now() - wall0;
    await page.waitForFunction(() => window.ASHEN, null, {timeout: 60000});
    const ashenSeenMs = Date.now() - wall0;
    const mark = async (pred, timeout = 120000) => {
      const t = Date.now();
      await page.waitForFunction(pred, null, {timeout});
      return Date.now() - wall0;
    };
    const playableWallMs = await mark(() => window.ASHEN?.playableReady);
    const navigationWallMs = await mark(() => window.ASHEN?.navigationReady);
    const hostilesWallMs = await mark(() => window.ASHEN?.hostilesReady);
    const readyWallMs = await mark(() => window.ASHEN?.ready);
    const bootNative = await page.evaluate(() => {
      const a = ASHEN, t = a.startup.timings(), begin = t.begin;
      const rel = name => (t[name] != null && begin != null) ? t[name] - begin : null;
      return {
        userAgent: navigator.userAgent,
        viewport: {w: innerWidth, h: innerHeight, dpr: devicePixelRatio},
        playableMs: a.playableMs, navigationMs: a.navigationMs, loadMs: a.loadMs, regionMs: a.regionMs,
        flags: {
          ready: a.ready, playableReady: a.playableReady, combatReady: a.combatReady,
          navigationReady: a.navigationReady, regionReady: a.regionReady, hostilesReady: a.hostilesReady,
        },
        marksFromBegin: {
          playable: rel('playable'),
          navigationReady: rel('navigation-ready'),
          hostilesReady: rel('hostiles-ready'),
          ready: rel('ready'),
          regionReady: rel('region-ready'),
          firstGpuCompleted: rel('first-gpu-completed'),
        },
        gpu: {depthBundle: a.gpu?.depthBundle, errors: a.gpu?.errors?.slice?.() || []},
        hardwareConcurrency: navigator.hardwareConcurrency,
      };
    });
    const boot = {
      url: GAME_URL, commitMs, ashenSeenMs, playableWallMs, navigationWallMs, hostilesWallMs, readyWallMs,
      meanings: {
        playableMs: 'dressed character on Havok; first playable frame revealed',
        navigationMs: 'route render blocks and mesh/box collision installed',
        hostilesReady: 'town enemies registered',
        loadMs_ready: 'hostiles + foliage + textures finished; suite-level ASHEN.ready',
        regionMs: 'marked immediately after ready',
        wallMs: 'worker Date.now() from navigation commit, includes Vite/network',
        marksFromBegin: 'ASHEN.startup.timings() minus begin (in-page performance.now())',
      },
      native: bootNative,
      contention: 'unknown — user Edge game on 127.0.0.1:5173/?dev and user Vite 5173/4000 preserved',
    };
    await writeJson(path.join(CACHE, 'boot.json'), boot);
    await writeJson(path.join(BASE, 'boot.json'), boot);
    report.boot = boot;
    findings.push({level: 'pass', msg: `Boot ready=${bootNative.flags.ready} playableMs=${bootNative.playableMs} navigationMs=${bootNative.navigationMs} loadMs=${bootNative.loadMs}`});

    const api = await page.evaluate(compactActorSrc);
    await writeJson(path.join(CACHE, 'api-boot.json'), api);
    report.apiBoot = {
      scenarioList: api.scenarioList, trace: api.trace, enemyCount: api.enemyCount,
      gpu: api.gpu, audio: api.audio, exploration: api.exploration, objective: api.objective,
    };
    const apiOk = api.scenarioList?.length === 4
      && api.scenarioList.map(s => s.id).join() === 'dummy,pack,cathedral,mortal'
      && api.trace && api.trace.size === 0;
    findings.push({level: apiOk ? 'pass' : 'fail', msg: `API list=${JSON.stringify(api.scenarioList)} trace=${JSON.stringify(api.trace)}`});

    if (phase === 'capture') {
      await runCapture(page, context, report, findings, errors);
    } else {
      await runFunctional(page, report, findings, errors);
      if (phase === 'all') await runCapture(page, context, report, findings, errors);
    }
  } catch (err) {
    findings.push({level: 'fail', msg: `Fatal: ${err.message}`});
    report.fatal = {message: err.message, stack: err.stack};
  } finally {
    report.findings = findings;
    report.errors = errors;
    report.finished = new Date().toISOString();
    const reportName = phase === 'capture' ? 'capture-report.json' : 'report.json';
    await writeJson(path.join(CACHE, reportName), report);
    await writeJson(path.join(BASE, reportName), report);
    await cdp?.detach().catch(() => {});
    await context.close().catch(() => {});
    await browser.close().catch(() => {});
  }
  const failed = findings.some(f => f.level === 'fail') || errors.length > 0;
  console.log(JSON.stringify({ok: !failed, findings: findings.length, errors: errors.length, boot: report.boot?.native?.marksFromBegin || null}, null, 2));
  if (failed) process.exitCode = 1;
}

async function runFunctional(page, report, findings, errors) {
  const scenarios = {};
  await openDev(page);
  const ui = await page.evaluate(() => {
    const sel = document.querySelector('#dev-combat-scenario');
    const options = [...(sel?.options || [])].map(o => ({id: o.value, name: o.textContent}));
    const actions = ['combat-scenario', 'combat-restore', 'combat-trace', 'combat-trace-clear']
      .map(a => {
        const b = document.querySelector(`[data-action="${a}"]`);
        return {action: a, present: !!b, disabled: !!b?.disabled, text: b?.textContent || null};
      });
    return {
      options, actions,
      status: document.querySelector('[data-combat-status]')?.textContent || null,
      menuOpen: !!document.getElementById('game-menu') && !document.getElementById('game-menu').hidden,
    };
  });
  report.uiInspect = ui;
  findings.push({level: ui.options.length === 4 ? 'pass' : 'fail', msg: `UI options ${ui.options.map(o => o.id).join(',')}`});

  const before = await page.evaluate(compactActorSrc);
  await writeJson(path.join(CACHE, 'before-rehearsal.json'), before);

  await page.getByLabel('Combat rehearsal', {exact: true}).selectOption('dummy');
  await page.getByRole('button', {name: 'Start combat rehearsal', exact: true}).click();
  await page.waitForTimeout(400);
  const dummyAfterStart = await page.evaluate(compactActorSrc);
  await writeJson(path.join(CACHE, 'scenario-dummy.json'), dummyAfterStart);
  await page.screenshot({path: path.join(CACHE, 'stills/dummy.png'), type: 'png'});
  const dummyOk = dummyAfterStart.scenario === 'dummy' && dummyAfterStart.dev.god === false && dummyAfterStart.dev.flying === false
    && dummyAfterStart.player?.usingPhysics && dummyAfterStart.life?.hp === dummyAfterStart.life?.hpMax
    && dummyAfterStart.progress?.mana === dummyAfterStart.progress?.manaMax;
  findings.push({level: dummyOk ? 'pass' : 'fail', msg: `dummy start god=${dummyAfterStart.dev.god} fly=${dummyAfterStart.dev.flying} physics=${dummyAfterStart.player?.usingPhysics} hp=${dummyAfterStart.life?.hp} mana=${dummyAfterStart.progress?.mana}`});
  scenarios.dummy = dummyAfterStart;

  await focusCanvas(page);
  await page.keyboard.press('Tab');
  await page.keyboard.press('Digit1');
  await page.waitForTimeout(900);
  await page.keyboard.press('Digit1'); // same-key repress
  await page.waitForTimeout(400);
  const afterFire = await page.evaluate(compactActorSrc);
  await writeJson(path.join(CACHE, 'dummy-after-fire.json'), afterFire);
  findings.push({level: 'info', msg: `after fire mana=${afterFire.progress?.mana} pending=${afterFire.pendingSpell} dummyHp=${afterFire.dummy?.hp} trace=${afterFire.trace?.size} xp=${afterFire.progress?.xp}`});

  const xpUnchanged = afterFire.progress?.xp === before.progress?.xp;
  const explUnchanged = afterFire.exploration?.phase === before.exploration?.phase;
  findings.push({level: xpUnchanged && explUnchanged ? 'pass' : 'fail', msg: `xp ${before.progress?.xp}->${afterFire.progress?.xp} exploration ${before.exploration?.phase}->${afterFire.exploration?.phase}`});

  await page.keyboard.down('KeyW');
  await page.waitForTimeout(500);
  await page.keyboard.up('KeyW');
  const walked = await page.evaluate(compactActorSrc);
  findings.push({level: walked.player?.usingPhysics ? 'pass' : 'fail', msg: `walk physics=${walked.player?.usingPhysics} recoveries=${walked.player?.recoveries} dz=${(walked.player?.z - dummyAfterStart.player?.z).toFixed?.(3)}`});

  // Pause (menu) then restore via UI.
  await openDev(page);
  const pausedDuring = await page.evaluate(compactActorSrc);
  const restoreVisible = await page.getByRole('button', {name: 'Restore before rehearsal', exact: true});
  const restoreDisabled = await restoreVisible.isDisabled();
  await restoreVisible.click();
  await page.waitForTimeout(200);
  const pausedAfterRestore = await page.evaluate(compactActorSrc);
  await writeJson(path.join(CACHE, 'restore-paused.json'), {pausedDuring, pausedAfterRestore, before});
  const posClose = (a, b, eps = 0.05) => a && b && Math.abs(a.x - b.x) < eps && Math.abs(a.y - b.y) < eps && Math.abs(a.z - b.z) < eps;
  const restored = pausedAfterRestore.scenario === null
    && pausedAfterRestore.dev.god === before.dev.god
    && pausedAfterRestore.dev.flying === before.dev.flying
    && posClose(pausedAfterRestore.player, before.player, 0.15)
    && pausedAfterRestore.progress?.xp === before.progress?.xp
    && Math.abs((pausedAfterRestore.progress?.mana ?? -1) - (before.progress?.mana ?? -2)) < 0.05
    && restoreDisabled === false;
  findings.push({level: restored ? 'pass' : 'fail', msg: `paused restore scenario=${pausedAfterRestore.scenario} god=${pausedAfterRestore.dev.god} mana=${pausedAfterRestore.progress?.mana} vs before ${before.progress?.mana} pos ${JSON.stringify(pausedAfterRestore.player)} vs ${JSON.stringify(before.player)}`});

  // Trace export via UI.
  const [download] = await Promise.all([
    page.waitForEvent('download', {timeout: 8000}).catch(e => ({error: e.message})),
    page.getByRole('button', {name: 'Download combat timing trace', exact: true}).click(),
  ]);
  if (download && !download.error) {
    const dest = path.join(CACHE, 'trace/ashen-combat-trace-ui.json');
    await download.saveAs(dest);
    const raw = JSON.parse(await fs.readFile(dest, 'utf8'));
    const compactTrace = {
      schema: raw.schema, scenario: raw.scenario, dropped: raw.dropped,
      eventCount: raw.events?.length ?? 0,
      types: [...new Set((raw.events || []).map(e => e.type))],
      first: raw.events?.[0] || null, last: raw.events?.at?.(-1) || null,
    };
    await writeJson(path.join(CACHE, 'trace/ui-export-summary.json'), compactTrace);
    report.traceExport = compactTrace;
    findings.push({level: compactTrace.eventCount > 0 ? 'pass' : 'fail', msg: `UI trace export events=${compactTrace.eventCount} types=${compactTrace.types.join(',')}`});
  } else {
    findings.push({level: 'fail', msg: `UI trace download failed: ${download?.error || 'unknown'}`});
  }

  // Remaining three scenarios via UI, restore each while paused.
  for (const id of ['pack', 'cathedral', 'mortal']) {
    await openDev(page);
    const pre = await page.evaluate(compactActorSrc);
    await page.getByLabel('Combat rehearsal', {exact: true}).selectOption(id);
    const startBtn = page.getByRole('button', {name: 'Start combat rehearsal', exact: true});
    const disabled = await startBtn.isDisabled();
    if (disabled) {
      findings.push({level: 'fail', msg: `${id} start button disabled`});
      scenarios[id] = {disabled: true, pre};
      continue;
    }
    await startBtn.click();
    await page.waitForTimeout(500);
    const startedSnap = await page.evaluate(compactActorSrc);
    await page.screenshot({path: path.join(CACHE, `stills/${id}.png`), type: 'png'});
    await focusCanvas(page);
    await page.keyboard.down('KeyW');
    await page.waitForTimeout(350);
    await page.keyboard.up('KeyW');
    if (id === 'pack' || id === 'cathedral') {
      await page.keyboard.press('Tab');
      await page.waitForTimeout(150);
      await page.keyboard.press('Tab');
    }
    if (id === 'mortal') {
      await page.keyboard.press('Tab');
      await page.keyboard.press('KeyT');
      await page.waitForTimeout(4000);
    } else {
      await page.keyboard.press('Digit1');
      await page.waitForTimeout(800);
    }
    const played = await page.evaluate(compactActorSrc);
    const diag = startedSnap.enemies.filter(e => e.state === 'diagnostic' || e.lockedState);
    const godOff = startedSnap.dev.god === false && startedSnap.dev.flying === false && startedSnap.player?.flying === false;
    const physics = startedSnap.player?.usingPhysics;
    let note = `${id} godOff=${godOff} physics=${physics} recoveries=${played.player?.recoveries} diagEnemies=${diag.length} hp=${played.life?.hp} dead=${played.life?.dead} target=${played.target}`;
    if (id === 'pack') {
      const ok = godOff && physics && diag.length >= 3;
      findings.push({level: ok ? 'pass' : 'fail', msg: note});
    } else if (id === 'cathedral') {
      const los = startedSnap.losEnemies;
      findings.push({level: godOff && physics ? 'pass' : 'fail', msg: `${note} los=${JSON.stringify(los)}`});
    } else {
      findings.push({level: godOff && physics ? 'pass' : 'fail', msg: `${note} hpDrop=${(pre.life?.hp - played.life?.hp).toFixed?.(2)}`});
      if (played.life?.dead) findings.push({level: 'info', msg: 'mortal rehearsal produced death (allowed)'});
    }
    await writeJson(path.join(CACHE, `scenario-${id}.json`), {pre, startedSnap, played});
    scenarios[id] = {pre, startedSnap, played};

    await openDev(page);
    await page.getByRole('button', {name: 'Restore before rehearsal', exact: true}).click();
    await page.waitForTimeout(200);
    const restoredSnap = await page.evaluate(compactActorSrc);
    const okRestore = restoredSnap.scenario === null && posClose(restoredSnap.player, pre.player, 0.2)
      && restoredSnap.progress?.xp === pre.progress?.xp
      && Math.abs((restoredSnap.progress?.mana ?? 0) - (pre.progress?.mana ?? 0)) < 0.2;
    findings.push({level: okRestore ? 'pass' : 'fail', msg: `${id} restore scenario=${restoredSnap.scenario} mana ${pre.progress?.mana}->${restoredSnap.progress?.mana} posMatch=${posClose(restoredSnap.player, pre.player, 0.2)}`});
    await writeJson(path.join(CACHE, `restore-${id}.json`), {pre, restoredSnap});
  }

  report.scenarios = Object.fromEntries(Object.entries(scenarios).map(([k, v]) => [k, v.startedSnap || v]));
  const gpu = await page.evaluate(() => ({errors: ASHEN.gpu?.errors?.slice?.() || [], depthBundle: ASHEN.gpu?.depthBundle, backgroundError: ASHEN.backgroundError || null}));
  report.gpuAfterFunctional = gpu;
  if (gpu.errors.length) findings.push({level: 'fail', msg: `GPU errors: ${gpu.errors.join(' | ')}`});
  else findings.push({level: 'pass', msg: `GPU errors none, depthBundle=${gpu.depthBundle}`});
}

async function tabUntil(page, id, n = 12) {
  for (let i = 0; i < n; i++) {
    const cur = await page.evaluate(() => ASHEN.combat.targeting.current?.id || null);
    if (cur === id) return cur;
    await page.keyboard.press('Tab');
    await page.waitForTimeout(90);
  }
  return page.evaluate(() => ASHEN.combat.targeting.current?.id || null);
}

async function pinInternalResolution(page) {
  // No Developer control sets backing-store size; performance overlay only
  // displays it. Pin through the existing exposed metrics API, then assert
  // the real render canvas, not CSS/viewport.
  const pinned = await page.evaluate(async () => {
    const canvas = document.getElementById('renderCanvas') || document.querySelector('canvas');
    const before = {id: canvas?.id || null, width: canvas?.width ?? null, height: canvas?.height ?? null};
    const got = ASHEN.metrics.setInternalResolution(1280, 720);
    await ASHEN.whenNextGpuFrame?.();
    const after = document.getElementById('renderCanvas') || document.querySelector('canvas');
    return {
      method: 'ASHEN.metrics.setInternalResolution(1280,720)',
      developerUiControl: false,
      before, got,
      after: {id: after?.id || null, width: after?.width ?? null, height: after?.height ?? null},
      client: {w: after?.clientWidth ?? null, h: after?.clientHeight ?? null},
      viewport: {w: innerWidth, h: innerHeight, dpr: devicePixelRatio},
    };
  });
  if (pinned.after.width !== 1280 || pinned.after.height !== 720) {
    throw new Error(`Render canvas not 1280x720 after pin: ${JSON.stringify(pinned)}`);
  }
  return pinned;
}

async function runCapture(page, context, report, findings, errors) {
  const dir = path.join(CACHE, 'capture');
  await fs.mkdir(path.join(dir, 'frames'), {recursive: true});
  const pinned = await pinInternalResolution(page);
  await writeJson(path.join(dir, 'resolution-pin.json'), pinned);
  findings.push({level: 'pass', msg: `pinned ${pinned.method} canvas ${pinned.after.width}x${pinned.after.height} (was ${pinned.before.width}x${pinned.before.height})`});
  report.resolutionPin = pinned;
  await focusCanvas(page);
  await openDev(page);
  await page.getByLabel('Combat rehearsal', {exact: true}).selectOption('dummy');
  await page.getByRole('button', {name: 'Start combat rehearsal', exact: true}).click();
  await page.waitForTimeout(300);
  const pinnedAfterDummy = await pinInternalResolution(page);
  report.resolutionPinAfterDummy = pinnedAfterDummy;
  await focusCanvas(page);
  const actionLog = [];
  const t0 = Date.now();
  const mark = (name, extra = {}) => actionLog.push({
    t: (Date.now() - t0) / 1000, name, ...extra,
    diagnostic: /scenario|restore|teleport|diagnostic/i.test(name),
  });

  const manifest = {version: 1, ...await captureSurface(page), frames: []};
  const cdp = await context.newCDPSession(page);
  let captureError;
  const writes = [];
  cdp.on('Page.screencastFrame', event => {
    void cdp.send('Page.screencastFrameAck', {sessionId: event.sessionId}).catch(() => {});
    if (captureError) return;
    try {
      const name = `frame-${String(manifest.frames.length).padStart(5, '0')}.jpg`;
      const bytes = Buffer.from(event.data, 'base64');
      appendFrame(manifest, {name, timestamp: event.metadata.timestamp, bytes});
      writes.push(fs.writeFile(path.join(dir, 'frames', name), bytes).catch(e => { captureError = e; }));
    } catch (e) { captureError = e; }
  });
  await cdp.send('Page.startScreencast', {format: 'jpeg', quality: 86, maxWidth: 1280, maxHeight: 720, everyNthFrame: 4});
  mark('capture-start', {scenario: 'dummy', note: 'diagnostic placement'});

  const press = async (key, hold = 0) => {
    mark(`keydown:${key}`);
    await page.keyboard.down(key);
    if (hold) await page.waitForTimeout(hold);
    await page.keyboard.up(key);
    mark(`keyup:${key}`);
  };
  const snapMark = async (name) => {
    const s = await page.evaluate(compactActorSrc);
    mark(name, {mana: s.progress?.mana, hp: s.life?.hp, dummyHp: s.dummy?.hp, target: s.target, pending: s.pendingSpell, casts: s.spells, scenario: s.scenario});
    return s;
  };

  let dummyTarget = await tabUntil(page, 'ashen-training-dummy');
  if (dummyTarget !== 'ashen-training-dummy') {
    await page.locator('#renderCanvas, canvas').first().click({position: {x: 640, y: 360}});
    await page.waitForTimeout(120);
    dummyTarget = await tabUntil(page, 'ashen-training-dummy', 14);
  }
  await page.waitForTimeout(200);
  dummyTarget = await page.evaluate(() => ASHEN.combat.targeting.current?.id || null);
  mark('pin dummy target', {target: dummyTarget, note: 'native Tab/click; do not claim dummy HP unless this id holds at start'});
  if (dummyTarget !== 'ashen-training-dummy') {
    findings.push({level: 'info', msg: `dummy not current after Tab/click (target=${dummyTarget}); later dummyHp is not dummy-damage evidence`});
  }
  await press('Digit1');
  await page.waitForTimeout(250);
  await press('Digit1');
  mark('Fire same-key repress during cast window');
  await page.waitForTimeout(1600);
  await snapMark('after-fire-repress');

  await press('Digit1');
  mark('Fire Blast after GCD');
  await page.waitForTimeout(1700);

  await press('Digit2');
  mark('Lava Ball start');
  await page.waitForTimeout(400);
  await press('Digit2');
  mark('Lava same-key repress during charge');
  await page.waitForTimeout(2800);
  await snapMark('after-lava');

  await press('Digit3');
  mark('Pyre Burst');
  await page.waitForTimeout(2000);
  await snapMark('after-pyre');

  mark('move+jump during Fire');
  await page.keyboard.down('KeyW');
  await press('Digit1');
  await page.waitForTimeout(180);
  await page.keyboard.down('Space');
  await page.waitForTimeout(200);
  await page.keyboard.up('Space');
  await page.waitForTimeout(1000);
  await page.keyboard.up('KeyW');
  await page.keyboard.down('KeyA');
  await page.waitForTimeout(500);
  await page.keyboard.up('KeyA');
  await page.keyboard.down('KeyD');
  await page.waitForTimeout(500);
  await page.keyboard.up('KeyD');
  await press('Digit1');
  await page.waitForTimeout(1600);

  await press('KeyT');
  mark('melee auto-attack');
  await page.waitForTimeout(2200);
  await snapMark('after-melee');

  await openDev(page);
  await page.getByLabel('Combat rehearsal', {exact: true}).selectOption('pack');
  await page.getByRole('button', {name: 'Start combat rehearsal', exact: true}).click();
  mark('scenario-pack-start', {note: 'diagnostic teleport/setup'});
  await page.waitForTimeout(350);
  await focusCanvas(page);
  const packIds = await page.evaluate(() => ASHEN.combat.enemies.slice(0, 3).map(e => e.id));
  for (const id of packIds) {
    const got = await tabUntil(page, id);
    mark(`Tab pack ${id}`, {target: got});
    await press('Digit1');
    await page.waitForTimeout(1500);
  }
  await press('Digit3');
  mark('Pyre on pack');
  await page.waitForTimeout(1800);
  await page.keyboard.down('KeyW');
  await press('Digit2');
  await page.waitForTimeout(800);
  await page.keyboard.up('KeyW');
  await press('KeyT');
  await page.waitForTimeout(1600);
  await snapMark('after-pack');

  mark('mana exhaustion spam Fire');
  for (let i = 0; i < 12; i++) {
    await press('Digit1');
    await page.waitForTimeout(420);
  }
  const mid = await snapMark('mana-check');

  await openDev(page);
  await page.getByLabel('Combat rehearsal', {exact: true}).selectOption('mortal');
  await page.getByRole('button', {name: 'Start combat rehearsal', exact: true}).click();
  mark('scenario-mortal-start', {note: 'diagnostic teleport/setup; God/Fly off; death allowed'});
  await page.waitForTimeout(300);
  await focusCanvas(page);
  await page.keyboard.press('Tab');
  await press('KeyT');
  await page.keyboard.down('KeyW');
  await page.waitForTimeout(5000);
  await page.keyboard.up('KeyW');
  await page.waitForTimeout(6000);
  await snapMark('mortal-contact');

  await openDev(page);
  await page.getByRole('button', {name: 'Restore before rehearsal', exact: true}).click();
  mark('combat-restore', {note: 'diagnostic restore'});
  await page.waitForTimeout(300);

  await cdp.send('Page.stopScreencast');
  cdp.removeAllListeners('Page.screencastFrame');
  await Promise.all(writes);
  if (captureError) throw captureError;
  await writeCaptureManifest(dir, manifest, await captureSurface(page));
  const endSnap = await page.evaluate(compactActorSrc);
  const traceSnap = await page.evaluate(() => {
    const t = ASHEN.combat.trace;
    const events = t.snapshot();
    const types = {};
    for (const e of events) types[e.type] = (types[e.type] || 0) + 1;
    return {size: t.size, dropped: t.dropped, types, events};
  });
  await writeJson(path.join(dir, 'action-log.json'), {
    elapsedSeconds: (Date.now() - t0) / 1000, actionLog, mid, endSnap, audio: endSnap.audio,
    note: 'Scenario teleports/setup/restore are diagnostic. Capture adds load; no FPS claim. Audio muted in this headless session.',
  });
  await writeJson(path.join(dir, 'trace.json'), {dropped: traceSnap.dropped, size: traceSnap.size, types: traceSnap.types, events: traceSnap.events});
  await cdp.detach().catch(() => {});
  report.capture = {
    frames: manifest.frames.length,
    elapsedSeconds: manifest.elapsedSeconds,
    viewport: manifest.viewport,
    canvas: manifest.canvas,
    devicePixelRatio: manifest.devicePixelRatio,
    actionCount: actionLog.length,
    audio: endSnap.audio,
    note: 'Capture adds load; no FPS claim. Scenario teleports/setup are diagnostic.',
  };
  findings.push({
    level: manifest.frames.length > 30 && manifest.elapsedSeconds >= 55 ? 'pass' : 'fail',
    msg: `capture frames=${manifest.frames.length} elapsed=${manifest.elapsedSeconds?.toFixed?.(3)} viewport=${manifest.viewport?.width}x${manifest.viewport?.height} dpr=${manifest.devicePixelRatio}`,
  });
}

await main();
