import fs from 'node:fs/promises';
import os from 'node:os';
import {execFileSync} from 'node:child_process';
import {chromium} from 'playwright';
import {browserOwnership} from '../../scripts/lib/browser-ownership.mjs';
const root = '.cache/combat-c01-2026-10-10';
const cdpPort = 10137, url = 'http://127.0.0.1:5973/?dev&play';
const browser = await chromium.connectOverCDP('http://127.0.0.1:' + cdpPort);
const existing = browser.contexts().flatMap(c=>c.pages()).filter(p=>p.url()!=='about:blank');
if (existing.length) throw Error('Unexpected pre-existing CDP page: '+existing.map(p=>p.url()));
const context = await browser.newContext({viewport:{width:1280,height:720},deviceScaleFactor:1});
const page = await context.newPage(), errors=[];
page.on('pageerror',e=>errors.push(e.message));
page.on('console',m=>{if(m.type()==='error') errors.push(m.text());});
const report = {sourceRuntime:'d7dce45', recordedAt:new Date().toISOString(), hardware:execFileSync('sysctl',['-n','machdep.cpu.brand_string'],{encoding:'utf8'}).trim(),os:os.release(),browser:browser.version(),viewport:[1280,720],dpr:1,conditions:'Uncapped Chromium WebGPU. God on for sustainable spell workload; diagnostic scenario placement. Seven enemies. No screenshots, recording or GPU timing readback during samples. RAF throughput, not physical display FPS.',runs:[],errors};
await fs.writeFile(root+'/benchmark-start.json',JSON.stringify(report,null,2));
try {
  report.ownership=await browserOwnership(browser,{cdpPort,url,purpose:'exclusive C01 raw combat FPS baseline',renderingClients:1});
  report.ownership.owner='grok-c01';
  await page.goto(url,{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>globalThis.ASHEN?.ready&&ASHEN.navigationReady&&ASHEN.hostilesReady,{},{timeout:90000});
  report.boot=await page.evaluate(()=>({loadMs:ASHEN.loadMs,playableMs:ASHEN.playableMs,enemies:ASHEN.combat.enemies.length,usingPhysics:ASHEN.player.getDebugState().usingPhysics}));
  if(report.boot.enemies!==7)throw Error('Expected seven enemies, got '+report.boot.enemies);
  await page.evaluate(()=>ASHEN.metrics.setInternalResolution(1280,720));
  await page.waitForTimeout(3000);
  for(const scenario of ['dummy','pack','mortal']) for(let repetition=1;repetition<=3;repetition++){
    const placed=await page.evaluate(s=>ASHEN.combat.scenarios.start(s),scenario);
    if(!placed)throw Error('Scenario unavailable: '+scenario);
    await page.locator('#renderCanvas').focus();
    await page.keyboard.press('g');
    await page.waitForTimeout(700);
    const god=await page.evaluate(()=>ASHEN.combat.snapshot().dev.god);
    if(!god)throw Error('God must be enabled and labelled for sustainable performance workload');
    for(let i=0;i<16;i++){
      if(await page.evaluate(()=>ASHEN.combat.targeting.current?.id==='ashen-training-dummy'))break;
      await page.keyboard.press('Tab');await page.waitForTimeout(35);
    }
    const start=await page.evaluate(()=>{
      const c=document.getElementById('renderCanvas');
      if(c.width!==1280||c.height!==720)throw Error('Resolution changed');
      ASHEN.combat.trace.clear(); ASHEN.metrics.reset();
      return ASHEN.combat.snapshot();
    });
    const sample=page.evaluate(()=>new Promise(resolve=>{
      const raw=[];let first=null,previous;
      function frame(t){
        if(first===null){first=previous=t;requestAnimationFrame(frame);return;}
        raw.push(t-previous);previous=t;
        if(t-first>=12000)resolve(raw);else requestAnimationFrame(frame);
      }
      requestAnimationFrame(frame);
    }));
    const inputLog=[], schedule=[[0,'Digit2'],[1300,'Digit1'],[2800,'Digit1'],[4300,'Digit1'],[5800,'Digit3'],[7300,'Digit2'],[8600,'Digit1'],[10000,'Digit1'],[11500,'Digit1']];
    const actions=(async()=>{
      const beginning=performance.now();
      for(const [at,key] of schedule){
        const wait=at-(performance.now()-beginning);
        if(wait>0)await new Promise(r=>setTimeout(r,wait));
        inputLog.push({atMs:performance.now()-beginning,key});await page.keyboard.press(key);
      }
    })();
    const [raw]=await Promise.all([sample,actions]);
    const end=await page.evaluate(()=>({combat:ASHEN.combat.snapshot(),trace:ASHEN.combat.trace.snapshot(),metrics:ASHEN.metrics.summary(),gpuErrors:ASHEN.gpu?.errors?.slice()??[]}));
    // Avoid retaining renderer objects if the GPU diagnostic surface grows.
    const sorted=[...raw].sort((a,b)=>a-b),sum=raw.reduce((a,b)=>a+b,0);
    const percentile=p=>sorted[Math.floor((sorted.length-1)*p)];
    report.runs.push({scenario,repetition,elapsedMs:sum,frames:raw.length,fps:raw.length*1000/sum,p50:percentile(.5),p95:percentile(.95),p99:percentile(.99),max:sorted.at(-1),over16_67:raw.filter(x=>x>16.67).length,over33_33:raw.filter(x=>x>33.33).length,over50:raw.filter(x=>x>50).length,inputLog,start,end,raw});
    await fs.writeFile(root+'/benchmark.json',JSON.stringify(report,null,2));
    process.stdout.write(JSON.stringify({scenario,repetition,fps:report.runs.at(-1).fps,p99:report.runs.at(-1).p99})+'\n');
  }
} finally {
  await context.close(); await browser.close();
  report.finishedAt=new Date().toISOString();
  await fs.writeFile(root+'/benchmark.json',JSON.stringify(report,null,2));
}
