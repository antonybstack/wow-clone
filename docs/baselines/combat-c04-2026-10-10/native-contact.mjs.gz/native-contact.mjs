import {chromium} from 'playwright';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const b=await chromium.connectOverCDP('http://127.0.0.1:10137'),c=await b.newContext({viewport:{width:1280,height:720},deviceScaleFactor:1}),p=await c.newPage();
const report={errors:[]};p.on('pageerror',e=>report.errors.push(e.message));
try{
 await p.goto('http://127.0.0.1:5973/?dev&play');await p.waitForFunction(()=>ASHEN?.ready&&ASHEN.navigationReady&&ASHEN.hostilesReady,null,{timeout:90000});
 await p.evaluate(()=>{ASHEN.metrics.setInternalResolution(1280,720);ASHEN.combat.scenarios.start('mortal');ASHEN.combat.trace.clear()});
 await p.locator('#renderCanvas').focus();await p.waitForTimeout(350);await p.keyboard.down('KeyW');await p.waitForTimeout(1000);await p.keyboard.up('KeyW');
 await p.waitForFunction(()=>ASHEN.combat.trace.snapshot().some(e=>e.type==='enemy-contact'&&e.connected),null,{timeout:7000});
 report.state=await p.evaluate(()=>({snapshot:ASHEN.combat.snapshot(),trace:ASHEN.combat.trace.snapshot(),player:{...ASHEN.player.body.position},physics:ASHEN.player.getDebugState().usingPhysics}));
 const hit=report.state.trace.find(e=>e.type==='enemy-contact'&&e.connected),start=report.state.trace.find(e=>e.type==='enemy-windup'&&e.sourceId===hit.sourceId);
 assert(start);assert(hit.time-start.time>=.5);assert(report.state.snapshot.life.hp<100);assert.equal(report.state.snapshot.dev.god,false);assert(report.state.physics);report.ok=true;
 await p.screenshot({path:'.cache/combat-c04-2026-10-10/mortal-contact.png'});
}catch(e){report.ok=false;report.error=e.message;report.state=await p.evaluate(()=>({snapshot:ASHEN.combat.snapshot(),trace:ASHEN.combat.trace.snapshot(),player:{...ASHEN.player.body.position}}));}
finally{await c.close();await b.close();await fs.writeFile('.cache/combat-c04-2026-10-10/contact-result.json',JSON.stringify(report,null,2));console.log({ok:report.ok,error:report.error});}
