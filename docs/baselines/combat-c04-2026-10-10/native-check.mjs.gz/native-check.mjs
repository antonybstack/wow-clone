import {chromium} from 'playwright';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {captureSurface,appendFrame,writeCaptureManifest} from '../../scripts/lib/capture-manifest.mjs';
import {browserOwnership} from '../../scripts/lib/browser-ownership.mjs';
const root='.cache/combat-c04-2026-10-10';
const browser=await chromium.connectOverCDP('http://127.0.0.1:10137');
if(browser.contexts().flatMap(c=>c.pages()).some(p=>p.url()!=='about:blank'))throw Error('Unexpected owned page');
const context=await browser.newContext({viewport:{width:1280,height:720},deviceScaleFactor:1});
const page=await context.newPage();page.setDefaultTimeout(6000);
const report={checks:[],errors:[]};let cdp,manifest,captureError;const writes=[];
page.on('pageerror',e=>report.errors.push(e.message));page.on('console',m=>{if(m.type()==='error')report.errors.push(m.text())});
const save=async()=>fs.writeFile(root+'/native-result.json',JSON.stringify(report,null,2));
const check=async(name,fn)=>{try{await fn();report.checks.push({name,ok:true})}catch(e){report.checks.push({name,ok:false,error:e.message,state:await state()});}console.log(report.checks.at(-1));await save()};
const state=()=>page.evaluate(()=>({combat:ASHEN.combat.snapshot(),trace:ASHEN.combat.trace.snapshot(),physics:ASHEN.player.getDebugState().usingPhysics,gpu:ASHEN.gpu.errors}));
const fixture=async(id='dummy')=>{
 await page.evaluate(id=>{if(!ASHEN.combat.scenarios.start(id))throw Error('Fixture unavailable');ASHEN.combat.trace.clear()},id);
 await page.locator('#renderCanvas').focus();await page.waitForTimeout(350);
 if(id==='dummy')for(let i=0;i<16;i++){if(await page.evaluate(()=>ASHEN.combat.targeting.current?.id==='ashen-training-dummy'))break;await page.keyboard.press('Tab');}
};
try{
 report.ownership=await browserOwnership(browser,{cdpPort:10137,url:'http://127.0.0.1:5973/?dev&play',purpose:'root C04 native feedback / binding acceptance and capture',renderingClients:1});
 await page.goto('http://127.0.0.1:5973/?dev&play');await page.waitForFunction(()=>ASHEN?.ready&&ASHEN.navigationReady&&ASHEN.hostilesReady,null,{timeout:90000});
 await page.evaluate(()=>ASHEN.metrics.setInternalResolution(1280,720));await page.waitForTimeout(1500);report.boot=await state();
 const dir=root+'/capture';await fs.mkdir(dir+'/frames',{recursive:true});manifest={version:1,...await captureSurface(page),frames:[]};cdp=await context.newCDPSession(page);
 cdp.on('Page.screencastFrame',e=>{void cdp.send('Page.screencastFrameAck',{sessionId:e.sessionId}).catch(()=>{});if(captureError)return;try{const name='frame-'+String(manifest.frames.length).padStart(5,'0')+'.jpg',bytes=Buffer.from(e.data,'base64');appendFrame(manifest,{name,timestamp:e.metadata.timestamp,bytes});writes.push(fs.writeFile(dir+'/frames/'+name,bytes));}catch(e){captureError=e;}});
 await cdp.send('Page.startScreencast',{format:'jpeg',quality:86,maxWidth:1280,maxHeight:720,everyNthFrame:4});
 await check('HUD shows queued Fire, cast and independent cooldown state',async()=>{
  await fixture();await page.keyboard.press('Digit2');await page.waitForFunction(()=>{const s=ASHEN.combat.scheduler;return s.active&&s.active.releaseAt-s.now<.27&&s.active.releaseAt-s.now>.08},null,{timeout:2500,polling:10});await page.keyboard.press('Digit1');
  await page.waitForFunction(()=>document.querySelector('[data-spell="1"]').classList.contains('queued'),null,{timeout:200});
  assert.equal(await page.locator('.cast-progress').isVisible(),true);report.queue=await page.locator('#combat').innerText();await page.screenshot({path:root+'/queue.png'});await page.waitForTimeout(1100);
  assert.equal(await page.locator('[data-spell="1"]').getAttribute('class').then(x=>x.includes('queued')),false);
  assert.equal((await state()).combat.dummy.hp,1640);
  assert.equal(await page.locator('.target-plate span').innerText(),'Training Dummy');
 });
 await check('Target panel stays fixed during strafe',async()=>{
  await fixture();const a=await page.locator('.target-plate').boundingBox();await page.keyboard.down('KeyE');await page.waitForTimeout(400);await page.keyboard.up('KeyE');const b=await page.locator('.target-plate').boundingBox();assert.equal(a.x,b.x);assert.equal(a.y,b.y);
 });
 await check('Mana refusal and bounded multi-target damage numbers are visible',async()=>{
  await fixture();await page.keyboard.press('Digit2');await page.waitForTimeout(1700);await page.keyboard.press('Digit1');await page.waitForTimeout(1600);await page.keyboard.press('Digit1');await page.waitForTimeout(200);
  assert.match(await page.locator('[data-spell="3"]').getAttribute('aria-label'),/Low mana/);await page.screenshot({path:root+'/mana.png'});
  await fixture('pack');await page.keyboard.press('Digit3');await page.waitForTimeout(150);
  const count=await page.locator('.damage-number:not([hidden])').count();report.damageCount=count;assert(count>=2&&count<=6);await page.screenshot({path:root+'/area.png'});
 });
 await check('Rebind through menu rejects duplicates, updates HUD, and changes actual cast key',async()=>{
  await fixture();await page.keyboard.press('Escape');await page.getByRole('button',{name:'Keybindings',exact:true}).click();
  await page.getByLabel('Fire Blast key',{exact:true}).selectOption('Digit2');assert.match(await page.locator('[data-binding-status]').innerText(),/already assigned/);
  await page.getByLabel('Fire Blast key',{exact:true}).selectOption('Digit8');await page.getByLabel('Attack key',{exact:true}).selectOption('KeyJ');
  await page.screenshot({path:root+'/bindings.png'});await page.keyboard.press('Escape');await page.locator('#renderCanvas').focus();
  assert.equal(await page.locator('[data-spell="1"] kbd').innerText(),'8');const before=(await state()).combat.dummy.hp;
  await page.keyboard.press('Digit1');await page.waitForTimeout(180);assert.equal((await state()).combat.dummy.hp,before);
  await page.keyboard.press('Digit8');await page.waitForTimeout(220);assert.equal((await state()).combat.dummy.hp,before-120);
 });
 await check('Mortal shade damage follows native windup; no God mode or recovery',async()=>{
  await fixture('mortal');assert.equal((await state()).combat.dev.god,false);
  await page.waitForFunction(()=>ASHEN.combat.trace.snapshot().some(e=>e.type==='enemy-contact'&&e.connected),null,{timeout:12000});
  const s=await state();report.mortal=s;
  const contact=s.trace.find(e=>e.type==='enemy-contact'&&e.connected),windup=s.trace.find(e=>e.type==='enemy-windup'&&e.sourceId===contact.sourceId);
  assert(windup);assert(contact.time-windup.time>=.5);assert(s.combat.life.hp<100);assert(s.physics);
  await page.screenshot({path:root+'/mortal.png'});
 });
 await check('Source-compatible Orc and Undead accept moving instants after actual armory swaps',async()=>{
  for(const race of ['orc','undead','human']){
    await fixture();await page.keyboard.press('KeyC');await page.locator('#armory [data-race]').selectOption(race);
    await page.waitForFunction(r=>ASHEN.equipment.race===r&&!document.querySelector('#armory [data-race]').disabled,race,{timeout:60000});
    await page.getByRole('button',{name:'Close armory',exact:true}).click();await page.locator('#renderCanvas').focus();await page.waitForTimeout(250);
    const before=await page.evaluate(()=>ASHEN.combat.spell.casts);await page.keyboard.down('KeyE');await page.waitForTimeout(180);await page.keyboard.press('Digit8');await page.waitForTimeout(180);await page.keyboard.up('KeyE');
    assert.equal(await page.evaluate(()=>ASHEN.combat.spell.casts),before+1);await page.screenshot({path:root+'/'+race+'.png'});
  }
 });
 await cdp.send('Page.stopScreencast');await Promise.all(writes);if(captureError)throw captureError;await writeCaptureManifest(dir,manifest,await captureSurface(page));
 await check('Bindings persist through actual reload',async()=>{
  await page.reload();await page.waitForFunction(()=>ASHEN?.ready&&ASHEN.hostilesReady,null,{timeout:90000});
  assert.equal(await page.locator('[data-spell="1"] kbd').innerText(),'8');assert.equal(await page.locator('#combat [data-attack] kbd').innerText(),'J');
 });
 report.final=await state();assert.equal(report.errors.length,0);await save();
}finally{await context.close();await browser.close();await save()}
if(report.checks.some(c=>!c.ok))process.exitCode=1;
