import {chromium} from 'playwright';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {captureSurface,appendFrame,writeCaptureManifest} from '../../scripts/lib/capture-manifest.mjs';
import {browserOwnership} from '../../scripts/lib/browser-ownership.mjs';
const root='.cache/combat-c03-2026-10-10';
const browser=await chromium.connectOverCDP('http://127.0.0.1:10137');
const context=await browser.newContext({viewport:{width:1280,height:720},deviceScaleFactor:1});
const page=await context.newPage();page.setDefaultTimeout(5000);const report={checks:[],errors:[],source:'e257894 + C03 working tree'};
page.on('pageerror',e=>report.errors.push(e.message));page.on('console',m=>{if(m.type()==='error')report.errors.push(m.text())});
let cdp,manifest,captureError;const writes=[];
const save=async()=>fs.writeFile(root+'/native-result.json',JSON.stringify(report,null,2));
const state=()=>page.evaluate(()=>({ ...ASHEN.combat.snapshot(),active:ASHEN.combat.scheduler.active,trace:ASHEN.combat.trace.snapshot(),body:ASHEN.body.getState(),menu:ASHEN.menu.isOpen,fireCasts:ASHEN.combat.spell.casts,lavaCasts:ASHEN.combat.lava.casts,pulseCasts:ASHEN.combat.pulse.casts,physics:ASHEN.player.getDebugState().usingPhysics,gpu:ASHEN.gpu.errors}));
const check=async(name,fn)=>{try{await fn();report.checks.push({name,ok:true});}catch(e){report.checks.push({name,ok:false,error:e.message,state:await state().catch(()=>null)});}await save();console.log(report.checks.at(-1).name,report.checks.at(-1).ok);};
async function fixture(){
 await page.evaluate(()=>{ASHEN.combat.scenarios.start('dummy');ASHEN.combat.trace.clear()});
 await page.locator('#renderCanvas').focus();await page.waitForTimeout(350);
 for(let i=0;i<16;i++){if(await page.evaluate(()=>ASHEN.combat.targeting.current?.id==='ashen-training-dummy'))return;await page.keyboard.press('Tab');await page.waitForTimeout(40);}
 throw Error('Could not target dummy through Tab');
}
try{
 report.ownership=await browserOwnership(browser,{cdpPort:10137,url:'http://127.0.0.1:5973/?dev&play',purpose:'root C02 native functional verification',renderingClients:1});
 await page.goto('http://127.0.0.1:5973/?dev&play');
 await page.waitForFunction(()=>ASHEN?.ready&&ASHEN.navigationReady&&ASHEN.hostilesReady,null,{timeout:90000});
 await page.waitForTimeout(3000); report.boot=await state();await save();
 await check('Developer resolution control',async()=>{
  await page.keyboard.press('Escape');await page.getByRole('button',{name:'Developer tools',exact:true}).click();
  await page.getByRole('button',{name:'Render 1280 pixels wide (keep aspect)',exact:true}).click();
  assert.deepEqual(await page.locator('#renderCanvas').evaluate(c=>[c.width,c.height]),[1280,720]);
  await page.getByLabel('Combat rehearsal',{exact:true}).selectOption('dummy');
  await page.getByRole('button',{name:'Start combat rehearsal',exact:true}).click();
  assert.equal(await page.evaluate(()=>ASHEN.menu.isOpen),false);
 });
 const dir=root+'/capture-v2';await fs.mkdir(dir+'/frames',{recursive:true});
 manifest={version:1,...await captureSurface(page),frames:[]}; cdp=await context.newCDPSession(page);
 cdp.on('Page.screencastFrame',e=>{void cdp.send('Page.screencastFrameAck',{sessionId:e.sessionId}).catch(()=>{});if(captureError)return;
  try{const name='frame-'+String(manifest.frames.length).padStart(5,'0')+'.jpg',bytes=Buffer.from(e.data,'base64');appendFrame(manifest,{name,timestamp:e.metadata.timestamp,bytes});writes.push(fs.writeFile(dir+'/frames/'+name,bytes));}catch(e){captureError=e;}});
 await cdp.send('Page.startScreencast',{format:'jpeg',quality:86,maxWidth:1280,maxHeight:720,everyNthFrame:4});
 await check('repress Fire does not cancel; spends once',async()=>{
  await fixture();const a=await state();await page.keyboard.press('Digit1');await page.waitForTimeout(100);await page.keyboard.press('Digit1');await page.waitForTimeout(700);const b=await state();
  report.repress={a,b};assert.equal(b.fireCasts-a.fireCasts,1);assert.equal(b.dummy.hp,1880);assert.equal(b.progress.mana,80);
 });
 await check('Lava reserves then releases to pinned target after Tab',async()=>{
  await fixture();await page.keyboard.press('Digit2');await page.waitForTimeout(180);const a=await state();assert.equal(a.reservedMana,40);assert.equal(a.progress.mana,100);
  await page.keyboard.press('Tab');await page.waitForTimeout(1900);const b=await state();report.lava={a,b};assert.equal(b.reservedMana,0);assert.equal(b.progress.mana,60);assert.equal(b.dummy.hp,1760);
 });
 await check('Escape stops cast, frees reservation, retains GCD; next opens menu',async()=>{
  await fixture();await page.keyboard.press('Digit2');await page.waitForTimeout(150);await page.keyboard.press('Escape');await page.waitForTimeout(70);const a=await state();report.escape=a;assert.equal(a.reservedMana,0);assert.equal(a.progress.mana,100);assert.equal(a.menu,false);assert(a.gcd>1);
  await page.keyboard.press('Escape');await page.waitForTimeout(80);assert.equal((await state()).menu,true);await page.getByRole('button',{name:/^Resume/}).click();
 });
 await check('Fire queued near Lava release runs before previous animation recovery ends',async()=>{
  await fixture();await page.keyboard.press('Digit2');await page.waitForTimeout(1290);await page.keyboard.press('Digit1');await page.waitForFunction(()=>ASHEN.combat.scheduler.queued?.abilityId==='fire-blast',null,{timeout:200});const a=await state();assert.equal(a.queue?.abilityId,'fire-blast');await page.waitForTimeout(950);const b=await state();report.queue={a,b};assert.equal(b.dummy.hp,1640);assert.equal(b.progress.mana,40);
 });
 await check('menu clears pending cast and queued action; resume does not replay',async()=>{
  await fixture();await page.keyboard.press('Digit2');await page.waitForTimeout(1300);await page.keyboard.press('Digit1');
  await page.evaluate(()=>ASHEN.menu.open());const a=await state();assert.equal(a.active,null);assert.equal(a.queue,null);await page.getByRole('button',{name:/^Resume/}).click();await page.waitForTimeout(800);const b=await state();report.menu={a,b};assert.equal(b.dummy.hp,2000);assert.equal(b.progress.mana,100);
 });
 await check('running Fire is instant and retains full movement',async()=>{
  await fixture();await page.keyboard.down('KeyE');await page.waitForTimeout(300);
  const a=await page.evaluate(()=>({speed:ASHEN.player.getMotion().speed,casts:ASHEN.combat.spell.casts,facing:ASHEN.player.getFacing()}));
  await page.keyboard.press('Digit1');await page.waitForFunction(n=>ASHEN.combat.spell.casts>n,a.casts,{timeout:250});await page.waitForTimeout(90);
  const b=await page.evaluate(()=>({speed:ASHEN.player.getMotion().speed,casts:ASHEN.combat.spell.casts,facing:ASHEN.player.getFacing(),trace:ASHEN.combat.trace.snapshot()}));
  await page.keyboard.up('KeyE');report.running={a,b};assert(b.speed>=a.speed*.95);assert.equal(b.facing,a.facing);assert.equal(b.casts,a.casts+1);
 });
 await check('airborne Fire releases without landing or resetting jump',async()=>{
  await fixture();await page.keyboard.down('Space');await page.waitForTimeout(130);await page.keyboard.up('Space');const a=await state();await page.keyboard.press('Digit1');await page.waitForTimeout(100);const b=await state();report.air={a,b};assert.equal(a.body.phase,'air');assert.equal(b.body.phase,'air');assert.equal(b.fireCasts-a.fireCasts,1);
  await page.screenshot({path:root+'/air-instant.png'});await page.waitForTimeout(1300);
 });
 await check('moving during Lava interrupts and refunds before release',async()=>{
  await fixture();await page.keyboard.press('Digit2');await page.waitForTimeout(200);assert.equal((await state()).reservedMana,40);await page.keyboard.down('KeyE');await page.waitForTimeout(180);await page.keyboard.up('KeyE');const b=await state();report.interrupt=b;assert.equal(b.reservedMana,0);assert.equal(b.progress.mana,100);assert.equal(b.dummy.hp,2000);
 });
 await check('airborne Pyre refuses; grounded Pyre releases immediately',async()=>{
  await fixture();await page.keyboard.down('Space');await page.waitForTimeout(130);await page.keyboard.up('Space');const a=await state();await page.keyboard.press('Digit3');await page.waitForTimeout(100);const b=await state();assert.equal(b.pulseCasts,a.pulseCasts);assert.equal(b.progress.mana,100);
  await page.waitForFunction(()=>ASHEN.player.getGrounded()&&ASHEN.body.getState().phase!=='air');await page.keyboard.press('Digit3');await page.waitForTimeout(100);const c=await state();report.pyre={a,b,c};assert.equal(c.pulseCasts-a.pulseCasts,1);assert.equal(c.progress.mana,70);await page.waitForTimeout(1000);
 });
 await check('pointer-locked Escape stops Lava before menu unlock guard',async()=>{
  await fixture();await page.mouse.move(650,360);await page.mouse.down({button:'right'});await page.mouse.move(656,360);await page.waitForTimeout(150);
  const locked=await page.evaluate(()=>!!document.pointerLockElement);assert(locked,'Native RMB did not acquire pointer lock');
  await page.keyboard.press('Digit2');await page.waitForTimeout(160);assert.equal((await state()).reservedMana,40);await page.keyboard.press('Escape');await page.waitForTimeout(80);const b=await state();report.pointerEscape=b;await page.mouse.up({button:'right'});assert.equal(b.reservedMana,0);assert.equal(b.menu,false);assert(b.gcd>1);
 });
 await cdp.send('Page.stopScreencast');cdp.removeAllListeners('Page.screencastFrame');await Promise.all(writes);if(captureError)throw captureError;await writeCaptureManifest(dir,manifest,await captureSurface(page));
 await check('queue setting persists actual reload',async()=>{
  await page.waitForTimeout(300);await page.keyboard.press('Escape');await page.getByRole('button',{name:'Keybindings',exact:true}).click();await page.getByLabel('Spell queue window',{exact:true}).selectOption('0.4');
  await page.reload();await page.waitForFunction(()=>ASHEN?.combatReady,null,{timeout:90000});
  assert.equal(await page.evaluate(()=>ASHEN.combat.scheduler.queueWindow),.4);
 });
 report.end=await state();await page.screenshot({path:root+'/native-end.png'});
}catch(e){report.failure=e.stack;await page.screenshot({path:root+'/native-failure.png'}).catch(()=>{});}finally{await save();await context.close();await browser.close();}
