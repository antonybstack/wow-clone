/** Public default-entry smoke for play.sparkify.dev. No /src imports on the page.
 * Mortal spawn, Havok, a short walk, optional CDP screencast. Not a startup gate.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {chromium} from 'playwright';
import {CDP_URL} from '../../scripts/lib/cdp.mjs';
import {browserOwnership} from '../../scripts/lib/browser-ownership.mjs';
import {appendFrame, captureSurface, writeCaptureManifest} from '../../scripts/lib/capture-manifest.mjs';

const dir = process.env.ASHEN_CAPTURE_DIR || '.cache/gothic-prod-2026-10-10/default-entry';
const url = process.env.ASHEN_TEST_URL || 'https://play.sparkify.dev/?play&clean&pixelRatio=1';
const recording = process.env.ASHEN_RECORD !== '0';
await fs.mkdir(`${dir}/frames`, {recursive: true});
const browser = await chromium.connectOverCDP(CDP_URL);
assert(browser.contexts().flatMap((c) => c.pages()).every((p) => p.url() === 'about:blank'));
const owner = await browserOwnership(browser, {
  cdpPort: new URL(CDP_URL).port,
  url,
  purpose: 'Public default-entry smoke and brief mortal walk on production; no FPS claim',
  renderingClients: 1,
});
await fs.writeFile(`${dir}/ownership.json`, JSON.stringify(owner, null, 2));
const report = {url, recording, errors: [], gpuErrors: null};
let context, page, cdp, manifest, captureError;
const writes = [];
try {
  context = await browser.newContext({viewport: {width: 1280, height: 720}, deviceScaleFactor: 1});
  page = await context.newPage();
  page.on('pageerror', (e) => report.errors.push(e.message));
  page.on('console', (m) => {
    if (m.type() === 'error') report.errors.push(m.text());
  });
  const started = Date.now();
  await page.goto(url, {waitUntil: 'commit'});
  await page.waitForFunction(() => globalThis.ASHEN?.ready && ASHEN.navigationReady && ASHEN.hostilesReady, null, {timeout: 120000});
  report.readyMs = Date.now() - started;
  await page.evaluate(() => ASHEN.metrics.setInternalResolution(1280, 720));
  const boot = await page.evaluate(() => ({
    physics: ASHEN.player.getDebugState().usingPhysics,
    recoveries: ASHEN.player.getDebugState().recoveries,
    god: ASHEN.dev.god,
    flying: ASHEN.player.isFlying(),
    gpuErrors: [...ASHEN.gpu.errors],
    href: location.href,
    srcImport: [...document.scripts].some((s) => (s.src || '').includes('/src/')),
  }));
  report.boot = boot;
  assert.equal(boot.physics, true);
  assert.equal(boot.recoveries, 0);
  assert.equal(boot.god, false);
  assert.equal(boot.flying, false);
  assert.deepEqual(boot.gpuErrors, []);
  assert.equal(boot.srcImport, false);
  assert(!/([?&]dev(=|&|$)|[?&]at=)/.test(boot.href));
  const start = await page.evaluate(() => ({
    x: ASHEN.player.body.position.x,
    y: ASHEN.player.body.position.y,
    z: ASHEN.player.body.position.z,
  }));
  if (recording) {
    manifest = {version: 1, ...await captureSurface(page), frames: [], markers: {}};
    cdp = await context.newCDPSession(page);
    cdp.on('Page.screencastFrame', (e) => {
      cdp.send('Page.screencastFrameAck', {sessionId: e.sessionId}).catch(() => {});
      if (captureError) return;
      try {
        const bytes = Buffer.from(e.data, 'base64');
        const name = `frame-${String(manifest.frames.length).padStart(5, '0')}.jpg`;
        appendFrame(manifest, {name, timestamp: e.metadata.timestamp, bytes});
        writes.push(fs.writeFile(`${dir}/frames/${name}`, bytes).catch((err) => { captureError ??= err; }));
      } catch (err) {
        captureError ??= err;
      }
    });
    await cdp.send('Page.startScreencast', {format: 'jpeg', quality: 88, maxWidth: 1280, maxHeight: 720, everyNthFrame: 2});
  }
  await page.keyboard.down('KeyW');
  await page.waitForTimeout(2500);
  await page.keyboard.up('KeyW');
  const end = await page.evaluate(() => ({
    x: ASHEN.player.body.position.x,
    y: ASHEN.player.body.position.y,
    z: ASHEN.player.body.position.z,
    physics: ASHEN.player.getDebugState().usingPhysics,
    recoveries: ASHEN.player.getDebugState().recoveries,
    god: ASHEN.dev.god,
    flying: ASHEN.player.isFlying(),
    gpuErrors: [...ASHEN.gpu.errors],
  }));
  report.start = start;
  report.end = end;
  report.moved = Math.hypot(end.x - start.x, end.z - start.z);
  assert(report.moved > 2, `Default spawn did not walk: ${JSON.stringify({start, end})}`);
  assert.equal(end.physics, true);
  assert.equal(end.recoveries, 0);
  assert.equal(end.god, false);
  assert.equal(end.flying, false);
  assert.deepEqual(end.gpuErrors, []);
  assert.deepEqual(report.errors, []);
  await page.screenshot({path: `${dir}/after-walk.png`});
  if (cdp) {
    await cdp.send('Page.stopScreencast');
    cdp = null;
    await Promise.all(writes);
    if (captureError) throw captureError;
    await writeCaptureManifest(dir, manifest, await captureSurface(page));
    report.frames = manifest.frames.length;
    report.elapsedSeconds = manifest.elapsedSeconds;
  }
  report.passed = true;
} catch (error) {
  report.passed = false;
  report.failure = error.stack;
  await page?.screenshot({path: `${dir}/failure.png`}).catch(() => {});
  throw error;
} finally {
  for (const key of ['KeyW', 'KeyA', 'KeyD']) await page?.keyboard.up(key).catch(() => {});
  if (cdp) await cdp.send('Page.stopScreencast').catch(() => {});
  await Promise.all(writes);
  await context?.close();
  await browser.close();
  await fs.writeFile(`${dir}/report.json`, JSON.stringify(report, null, 2));
  await fs.writeFile(`${dir}/ownership.json`, JSON.stringify({...owner, active: false, renderingClients: 0}, null, 2));
}
console.log(JSON.stringify({passed: report.passed, readyMs: report.readyMs, moved: report.moved, frames: report.frames, errors: report.errors.length}));
