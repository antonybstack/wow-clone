# Gothic production receipt review — 2026-10-09

Independent bounded review. Original assignment: five-turn cap, first batched
read then write observations, final turn for the report. This file is the
report-only completion after that cap. No further source reads, probes,
renderer, network, commands or calculations. Product and documents unchanged.
Only this path was written.

## Q1 — first valid cold default vs interrupted attempt vs later diagnostics

**Verdict: yes.** The first valid default sample is over the declared inclusive
1000 ms budget. The interrupted attempt and the two later instrumented
diagnostics are separate events.

### Declared budget and stop rule

`docs/baselines/gothic-production-2026-10-09/declaration.json`:

- kind: `gothic-production-qualification-declaration`
- source: `0b88344abbbea1411f8b5b6e90e8188954427108`
- preview: `https://aafce17b.fardel.pages.dev`
- sealSha256: `900b033a6da737a987207105e9b6bf1d2ccd47e48bb9948297c11f9b6f103278`
- runsEach: 20 across four named cohorts
- budgetMsInclusive: **1000**
- stopAtFirstInvalidOrOverBudget: **true**
- profile: 50/10 Mbps, 40 ms, HTTP cache disabled, fresh Chrome per start,
  1280×720, DPR 1, recording false, applicationPromiseObservers false

`failure-receipt.json` source is `7b9f5675a6bf50ed7c63aaf3277ab37835122e8f` with
productSource `4b6707a`. README states product-equivalent HEAD `0b88344`. Seal
hash matches. Related git IDs, not a mixed sample.

### First valid sample is over budget

`failed-cold-default.json` row 0, relevant fields only:

- playableMs: **1140.1000000238419**
- grounded: true, physics: true, loader: false
- canvas: 1280×720
- gpuErrors: [], tasks: []
- marks.begin: 477.4
- first-render-return: 608.6000000238419
- supported-frame-submitted: 633.8000000119209
- first-gpu-completed: 1131.9000000357628
- supported-frame-completed: 1139.699999988079
- playable: 1140.1000000238419
- bg-start: 1141
- region-index-request: 1144.1000000238419

1140.1 is above the inclusive 1000 ms budget.

`failure-receipt.json` restates the same playableMs and budget, nativeExit pid
75163 / code 1 / signal null, firstQueueCallbackWindowMs 523.3000000119209,
supportedQueueCallbackWindowMs 505.89999997615814. Those windows match the marks
as recorded in the first-pass arithmetic:

- 1131.9000000357628 − 608.6000000238419 = 523.3000000119209
- 1139.699999988079 − 633.8000000119209 = 505.8999999761582 (receipt rounding)

result: `FAILED; production unchanged`. completedGates: exact seal, three entry
aliases. stoppedGates: remaining 79 cold starts, post-startup native release
suite, release FPS phase, production promotion. errors and gpuErrors empty.
requestsAtBoundary 29, encodedBytesAtBoundary 2193984.
screenshotReviewedByRoot true. This is a completed dressed/grounded playable
sample that missed budget.

### Interrupted attempt is a different, invalid event

`interrupted-attempt.json`:

- at: 2026-10-09T16:55:16.353381+00:00
- reason: Root cancelled Grok64133 after no visible boot; operator had
  concurrently started its first cold child. Cancellation closed childChrome71663;
  child records Target page/context/browser closed. Native three-entry
  prerequisite passed; no timing sample accepted.
- child: `preview/cold-default-01.json`
- result: invalid harness-staging attempt retained, not a product fetch failure;
  no production mutation

PIDs differ: interrupted Chrome **71663** vs valid sample nativeExit **75163**.
README classifies the interrupted sample as invalid. Root then ran the operator
directly with separate output names (`preview-root2`). The failed valid sample
is not the cancelled child.

### Two later instrumented diagnostics are separate and non-qualifying

`diagnostic-declaration.json` (declared before those two visits):

- method: one default start each on immutable candidate and existing production,
  sequential fresh Chrome; same 50/10 Mbps 40 ms, HTTP cache disabled, 1280×720
  DPR1; optional GPU API events and Chrome trace; **no startup acceptance
  budget**, no recording/FPS. CPU API duration and queue callback wall time are
  not hardware GPU timing. Stop after these two visits; no unchanged qualifying
  retry.
- candidate: `https://aafce17b.fardel.pages.dev`
- control: `https://5723a4ab.fardel.pages.dev`

`failure-receipt.json` diagnostics[]:

| name | url | playableMs | firstQueueCallbackWindowMs | inputUpperBoundMs | pipelineCallsBeforePlay | browserPid | diagnosticOnly |
| --- | --- | --- | --- | --- | --- | --- | --- |
| candidate | aafce17b | 739.5 | 80.0 | 32.19999998807907 | 53 | 88327 | true |
| control | 5723a4ab | 912.8000000119209 | 81.5 | 31.5 | 53 | 89178 | true |

Both reportPath/tracePath are under `.cache/gothic-production-2026-10-09/diagnostics/`.
Both createRenderPipeline only, same 22 named labels. errors and gpuErrors empty.

Separation holds on purpose (qualifying cold start vs declared diagnostic with
no acceptance budget), PIDs (71663 / 75163 / 88327 / 89178), playableMs (none
for interrupted; 1140.1 vs 739.5 vs 912.8), first queue windows (523.3 ms vs
~80 ms), and inputUpperBoundMs (4284.2 on the failed sample, stated as
harness+fence, vs ~32 ms on diagnostics). Receipt flags diagnosticOnly true.
Neither diagnostic reproduces the 1140.1 ms sample.

### Q1 factual notes

- Declaration source `0b88344…` vs failure-receipt source `7b9f5675…` /
  productSource `4b6707a` is a documented source-id split. Seal matches.
- Failure-receipt stoppedGates still lists `release FPS phase`. That is a
  snapshot of the startup stop.
- Request dump omitted by instruction. Boundary counts are from the receipt.

## Q2 — performance-receipt vs fps.json.gz

**Verdict: not independently accepted.** Native exit, ownership, declaration and
measurement-script interpretation were read and agree with the receipt’s
wording. Agreement of all 15 rows and raw frames in `fps.json.gz` was not
recomputed. That check is required for the receipt’s numeric claim.

### What was read

`performance-receipt.json`:

- passed: true
- source: `7b9f5675a6bf50ed7c63aaf3277ab37835122e8f`
- sealSha256 matches declaration
- url: `https://aafce17b.fardel.pages.dev/?play=&clean=&pixelRatio=1`
- 1280×720, 12 s, 3 runs, uncappedRequired true, recording false
- routes: meadow, town, bridge, cathedral, forest
- windowCount: 15
- rawIntervalCount: 35133
- rawSha256: `300224a23c16fde9de47e0364132f66bec29acf9b04691a80809de1f77086939`
- minFPS: 175.195981238422
- maxFPS: 211.5978973504482
- maximumP95Ms: 6.699999988079071
- maximumP99Ms: 6.900000035762787
- worstMs: 10.199999988079071
- above16_667: 0
- errors: []
- interpretation: Independent settled default-mode region FPS acceptance for
  final G06–G08 integration. Diagnostic placements and God on; Havok active,
  Fly off. RAF throughput, not display refresh, timed landmark traversal, cold
  streaming tail acceptance or production comparison. Failed startup gate
  remains failed.
- nativeExits: up pid 91322 / fps 91441 / down 99306, all code 0, signal null
- ownership: root, browserPid 91407, gpuHelper 91413, cdp 10037,
  renderingClients 0, active false
- cleanupLog: Slot 7 Chrome/Vite stopped, slot down

Route table as printed on the receipt:

- meadow 187.09 / 187.10 / 187.18, maxP99 6.70 ms, worst 8.40 ms
- town 175.20 / 180.71 / 180.47, maxP99 6.90 ms, worst 10.20 ms
- bridge 211.18 / 211.13 / 211.60, maxP99 6.20 ms, worst 8.20 ms
- cathedral 204.92 / 205.04 / 205.01, maxP99 6.40 ms, worst 8.70 ms
- forest 189.51 / 194.54 / 196.19, maxP99 6.60 ms, worst 8.80 ms

All 15 listed FPS values on the receipt are above 144. Receipt min/max match
the town first window and the bridge third window at displayed precision.

Native files that match those exit/ownership fields:

- `.cache/gothic-production-2026-10-09/performance/up.exit.json` pid 91322 code 0
- `fps.exit.json` pid 91441 code 0
- `down.exit.json` pid 99306 code 0
- `fps.json.ownership.json` owner root, browserPid 91407, gpuHelper 91413,
  cdp 10037, renderingClients 0, active false
- `performance/declaration.json`: independent-final-G06-G08-performance-acceptance;
  floorFPSExclusive 120; targetFPS 144; startupQualification failed separately
  at 1140.1 ms; this FPS result cannot authorize promotion

### Script interpretation (`scripts/ashen-reach/measure-region-fps.mjs`)

Read in full during the original turns. The receipt’s interpretation language
matches what the script does:

- Uncapped harness, recording false, gpu timestamp queries stripped from the URL
- Viewport 1280×720, DPR 1, 3×12 s, five named routes
- `ASHEN.dev.god = true` and `ASHEN.setView("play")` before sampling
- Each window teleports to a hardcoded world position (meadow 0/−65, town 0/80,
  bridge 0/210, cathedral 0/280, forest −80/180), Fly off (`setFlying(false)`),
  1200 ms settle, W held 800 ms, then a 12 s RAF measurement
- Asserts physics true, enemies === 7, recoveries unchanged vs the pre-window
  count, hypot(displacement) > 10, resolution [1280, 720]
- Judges `fullWindow` / `fullWindowCap` on the complete interval list; HUD
  rolling-window cap is retained as a hint and is not the acceptance window
- `recordCapped` false (receipt) requires `!row.fullWindowCap.vsyncCapped`
- Errors array must be empty

That is settled RAF throughput at diagnostic placements with God on. It is
ordinary W-hold motion after teleport, not a timed landmark tour from spawn
and not a cold streaming-tail start. No production comparison is in the
receipt or the performance declaration.

### Unchecked for Q2

- `docs/baselines/gothic-production-2026-10-09/fps.json.gz` was not
  decompressed, hashed, or row-walked
- Independent confirmation of 15 rows, 35133 intervals, rawSha256, min/max
  FPS, p95/p99/worst, above16_667, enemies, Havok, displacement, recoveries
  and per-row fullWindowCap from raw frames
- fps.log / up.log / down.log bodies beyond the exit JSON files
- GPU helper liveness beyond the ownership snapshot

## Q3 — region background after first play; callback time vs shader attribution

**Verdict: supported for the main.js boundaries that were read.** Region
background is scheduled after the playable mark. Queue-callback elapsed time
in this sample cannot by itself name a shader regression. The installed native
async shader module was not opened.

### Source boundaries that were read (`src/ashen-reach/main.js`)

Playable path (around 676–704): `renderLoop.start()`, mark
`first-render-return`, `waitForGpuIdle` then mark `first-gpu-completed`, await
that fence and the grounded supported-frame promise, `finishLoading()`,
`setInputEnabled(true)`, then mark `playable` and reach `playableBoundary`.

Comments on that fence: Lite’s public GPU fence reports completion of already
submitted work, not scanout; a further `waitForGpuIdle` here adds a queue
callback and no GPU work.

Background path (725–755): after playable, `showBackgroundLoading()` then
`ashen.whenRest` async IIFE marks `bg-start` and starts skyline, nearby
foliage, and `world.startRegion` (which records `region-index-request` in the
failed sample). Comment: the starting area’s exact render/collision is already
playable; distant work lands while the player is walking.

`prime-world-skipped` is marked when `primeStartingWorld` is on and the body
request has already settled (397–410). That matches the failed sample’s
`prime-world-skipped` at 555.1 ms, immediately after havok-end.

Failed-sample mark order is consistent with this source: playable 1140.1,
bg-start 1141, region-index-request 1144.1. Background start after first play
cannot explain the 523.3 ms first-queue window that ended at 1131.9 ms.

Callback elapsed time (first-gpu-completed − first-render-return) is the
queue/callback wall interval documented in main.js and in the diagnostic
declaration (“CPU API duration and queue callback wall time are not hardware
GPU timing”). That interval does not identify which shader, driver work, or
callback scheduling caused the delay.

### Async compilation / negative trials

Workspace grep during the original turns found no
`enableAsyncShaderPipelineCompilation` / `createAsyncPipeline` in js/mjs/json.
Historical docs state async ShaderMaterial compilation stays disabled after
negative load trials. README states existing negative async trials remain
valid absent new attributable evidence. No speculative product fix is claimed.

### Unchecked for Q3

- Installed native Lite async-shader module under `node_modules` was not
  opened
- Engine create-options in main.js were not re-read beyond the playable/bg
  and prime-world slices
- Diagnostic traces were not rehashed or inspected for pipeline labels
  beyond the receipt summaries

## Unchecked limits (all questions)

- fps.json.gz contents and hash
- interrupted child `preview/cold-default-01.json` body
- diagnostic JSON/trace files beyond receipt sha256 paths
- installed `@babylonjs/lite` async shader module
- no production comparison
- no renderer, benchmark, network, build, deployment or messaging in this
  review

Root owns acceptance.
