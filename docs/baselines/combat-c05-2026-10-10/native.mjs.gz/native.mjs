import {chromium} from 'playwright';import fs from 'node:fs/promises';import assert from 'node:assert/strict';
import {captureSurface,appendFrame,writeCaptureManifest} from '../../scripts/lib/capture-manifest.mjs';import {browserOwnership} from '../../scripts/lib/browser-ownership.mjs';
const root='.cache/combat-c05-2026-10-10',b=await chromium.connectOverCDP('http://127.0.0.1:10137');if(b.contexts().flatMap(c=>c.pages()).some(p=>p.url()!=='about:blank'))throw Error('Extra page');
const c=await b.newContext({viewport:{width:1280,height:720},deviceScaleFactor:1}),p=await c.newPage(),r={checks:[],errors:[]};p.setDefaultTimeout(5000);p.on('pageerror',e=>r.errors.push(e.message));p.on('console',m=>{if(m.type()==='error')r.errors.push(m.text())});
const state=()=>p.evaluate(()=>({s:ASHEN.combat.snapshot(),trace:ASHEN.combat.trace.snapshot(),physics:ASHEN.player.getDebugState().usingPhysics}));
const save=()=>fs.writeFile(root+'/native.json',JSON.stringify(r,null,2));
const check=async(name,fn)=>{try{await fn();r.checks.push({name,ok:true});}catch(e){r.checks.push({name,ok:false,error:e.message,state:await state()});}console.log(r.checks.at(-1).name,r.checks.at(-1).ok);await save();};
const targetDummy=async()=>{for(let i=0;i<16;i++){if(await p.evaluate(()=>ASHEN.combat.targeting.current?.id==='ashen-training-dummy'))return;await p.keyboard.press('Tab');}throw Error('Dummy not selected');};
const fixture=async()=>{assert(await p.evaluate(()=>ASHEN.combat.scenarios.start('dummy')));await p.locator('#renderCanvas').focus();await p.waitForTimeout(250);await targetDummy();await p.evaluate(()=>ASHEN.combat.trace.clear());};
let cd,manifest,error;const writes=[];
try{
 r.ownership=await browserOwnership(b,{cdpPort:10137,url:'http://127.0.0.1:5973/?dev&play',purpose:'root C05 native Brand and sustained combat acceptance',renderingClients:1});
 await p.goto('http://127.0.0.1:5973/?dev&play');await p.waitForFunction(()=>window.ASHEN?.ready&&ASHEN.navigationReady&&ASHEN.hostilesReady,null,{timeout:90000});await p.evaluate(()=>ASHEN.metrics.setInternalResolution(1280,720));await p.waitForTimeout(1000);
 const dir=root+'/capture';await fs.mkdir(dir+'/frames',{recursive:true});manifest={version:1,...await captureSurface(p),frames:[]};cd=await c.newCDPSession(p);
 cd.on('Page.screencastFrame',e=>{void cd.send('Page.screencastFrameAck',{sessionId:e.sessionId}).catch(()=>{});if(error)return;try{const name='frame-'+String(manifest.frames.length).padStart(5,'0')+'.jpg',bytes=Buffer.from(e.data,'base64');appendFrame(manifest,{name,timestamp:e.metadata.timestamp,bytes});writes.push(fs.writeFile(dir+'/frames/'+name,bytes));}catch(e){error=e;}});
 await cd.send('Page.startScreencast',{format:'jpeg',quality:86,maxWidth:1280,maxHeight:720,everyNthFrame:4});
 await check('Native introduction teaches and unlocks Brand',async()=>{await p.locator('#renderCanvas').focus();await p.keyboard.press('Digit4');assert(await p.locator('.combat-lesson').isVisible());await p.screenshot({path:root+'/lesson.png'});await p.getByRole('button',{name:'Learn Ashen Brand',exact:true}).click();assert((await state()).s.brandLearned);});
 await check('One Brand applies six 15-damage ticks, exact cadence, then expires',async()=>{await fixture();await p.keyboard.press('Digit4');await p.waitForTimeout(12300);const s=await state(),ticks=s.trace.filter(e=>e.type==='hit'&&e.abilityId==='ashen-brand');r.single=s;assert.equal(ticks.length,6);assert.equal(s.s.dummy.hp,1910);assert.equal(s.s.auras.length,0);for(let i=1;i<6;i++)assert(Math.abs(ticks[i].time-ticks[i-1].time-2)<1e-7);assert.equal(s.s.dev.god,false);});
 await check('Refresh window is visible and refresh preserves next tick and carries remaining time',async()=>{await fixture();await p.keyboard.press('Digit4');await p.waitForTimeout(8700);assert.match(await p.locator('.target-auras').innerText(),/Refresh now/);await p.screenshot({path:root+'/refresh.png'});const before=(await state()).s.auras[0];await p.keyboard.press('Digit4');await p.waitForTimeout(100);const after=(await state()).s.auras[0];assert.equal(after.id,before.id);assert.equal(after.nextTickAt,before.nextTickAt);assert(Math.abs(after.expiresAt-before.expiresAt-12)<.01);await p.waitForTimeout(1600);await p.keyboard.press('Digit1');await p.waitForTimeout(350);r.refresh=await state();});
 await cd.send('Page.stopScreencast');await Promise.all(writes);if(error)throw error;await writeCaptureManifest(dir,manifest,await captureSurface(p));
 await check('Ninety-second ordinary-cost rhythm remains playable without resource dead stops',async()=>{
  await fixture();let started=await p.evaluate(()=>ASHEN.combat.life.time),attempts=0,lowMana=0,minMana=100,dead=false;const rounds=[];
  while(await p.evaluate(()=>ASHEN.combat.life.time)-started<90){
   const s=await state();if(s.s.life.dead){dead=true;break;}
   minMana=Math.min(minMana,s.s.progress.mana);if(s.s.dummy.hp<=0){await p.waitForTimeout(100);continue;}
   await targetDummy();const aura=s.s.auras.find(a=>a.targetId==='ashen-training-dummy');const cd=await p.evaluate(()=>ASHEN.combat.scheduler.cooldown('lava-ball'));
   const key=!aura||aura.remaining<3?'Digit4':cd===0&&s.s.progress.mana>=12?'Digit2':'Digit1';
   await p.keyboard.press(key);attempts++;await p.waitForTimeout(key==='Digit2'?1525:1515);
   const next=await state();lowMana=next.trace.filter(e=>e.type==='action-rejected'&&e.reason==='Not enough mana').length;rounds.push({time:next.s.life.time,mana:next.s.progress.mana,hp:next.s.life.hp,key});
  }
  r.sustained={elapsed:await p.evaluate(()=>ASHEN.combat.life.time)-started,attempts,lowMana,minMana,dead,rounds,final:await state()};assert(!dead,'Player died during sustained dummy test');assert(attempts>=48);assert.equal(lowMana,0);assert.equal(r.sustained.final.s.dev.god,false);assert(r.sustained.final.physics);
 });
 await check('Brand learning persists through actual reload',async()=>{await p.reload();await p.waitForFunction(()=>window.ASHEN?.ready&&ASHEN.hostilesReady,null,{timeout:90000});assert((await state()).s.brandLearned);});
 r.final=await state();assert.equal(r.errors.length,0);await save();
}finally{await c.close();await b.close();await save();}
if(r.checks.some(x=>!x.ok))process.exitCode=1;
