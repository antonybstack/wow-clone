import fs from 'node:fs/promises';
import os from 'node:os';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';

const require = createRequire(new URL('../../../../../package.json', import.meta.url));
const {chromium} = require('playwright');
const outputDir = fileURLToPath(new URL('.', import.meta.url));
const url = process.env.ASHEN_URL || 'http://127.0.0.1:5873/ashen-reach.html?play&clean';
const cdp = process.env.ASHEN_CDP_PORT || '10037';
const reportName = process.env.ASHEN_LOAD_REPORT || 'load-report-local.json';
const browser = await chromium.connectOverCDP(`http://127.0.0.1:${cdp}`);
const version = browser.version();
const context = await browser.newContext({viewport:{width:1280,height:720},deviceScaleFactor:1,serviceWorkers:'block'});
const page = await context.newPage();
const session = await context.newCDPSession(page);
const runs = [];
try {
  await session.send('Network.enable');
  await session.send('Network.clearBrowserCache');
  await page.addInitScript(() => {
    globalThis.__baselineLoad = {readyAt:null,hostilesAt:null,firstAshenAt:null,firstGpuFrameAt:null,rafGaps:[],longAnimationFrames:[]};
    let previousFrame = null;
    const sampleFrame = time => {
      if (previousFrame !== null) __baselineLoad.rafGaps.push(time-previousFrame);
      previousFrame = time;
      if (__baselineLoad.readyAt === null || __baselineLoad.hostilesAt === null) requestAnimationFrame(sampleFrame);
    };
    requestAnimationFrame(sampleFrame);
    if (PerformanceObserver.supportedEntryTypes?.includes('long-animation-frame')) {
      new PerformanceObserver(list => {
        for (const e of list.getEntries()) __baselineLoad.longAnimationFrames.push({startTime:e.startTime,duration:e.duration});
      }).observe({type:'long-animation-frame',buffered:true});
    }
    const timer = setInterval(() => {
      const a = globalThis.ASHEN;
      const now = performance.now();
      if (a && __baselineLoad.firstAshenAt === null) __baselineLoad.firstAshenAt = now;
      if (a?.gpu?.frames > 0 && __baselineLoad.firstGpuFrameAt === null) __baselineLoad.firstGpuFrameAt = now;
      if (a?.ready && __baselineLoad.readyAt === null) __baselineLoad.readyAt = now;
      if (a?.hostilesReady && __baselineLoad.hostilesAt === null) __baselineLoad.hostilesAt = now;
      if (__baselineLoad.readyAt !== null && __baselineLoad.hostilesAt !== null) clearInterval(timer);
    }, 4);
  });
  const labels = ['cold-browser-cache','warm-browser-cache-1','warm-browser-cache-2'].slice(0,Number(process.env.ASHEN_LOAD_RUNS || 3));
  for (const label of labels) {
    const errors = [];
    const failedRequests = [];
    const httpErrors = [];
    const onPageError = e => errors.push(e.message);
    const onConsole = m => {if (m.type() === 'error') errors.push(m.text());};
    const onRequestFailed = r => failedRequests.push({url:r.url(),failure:r.failure()?.errorText});
    const onResponse = r => {if (r.status() >= 400) httpErrors.push({url:r.url(),status:r.status()});};
    page.on('pageerror',onPageError);
    page.on('console',onConsole);
    page.on('requestfailed',onRequestFailed);
    page.on('response',onResponse);
    const startedAt = new Date().toISOString();
    await page.goto(url,{waitUntil:'commit',timeout:120000});
    await page.waitForFunction(() => globalThis.ASHEN?.ready && ASHEN.hostilesReady,null,{timeout:120000,polling:25});
    await page.waitForTimeout(500);
    const inPage = await page.evaluate(() => {
      const n = performance.getEntriesByType('navigation')[0];
      const paints = performance.getEntriesByType('paint').map(e => ({name:e.name,startTime:e.startTime}));
      const resources = performance.getEntriesByType('resource');
      const a = globalThis.ASHEN;
      const sum = key => resources.reduce((total,r) => total+(Number(r[key])||0),0);
      const gaps = globalThis.__baselineLoad.rafGaps;
      const sortedGaps = [...gaps].sort((a,b)=>a-b);
      const spikes = {sampleCount:gaps.length,p95:sortedGaps[Math.floor(sortedGaps.length*.95)]??null,p99:sortedGaps[Math.floor(sortedGaps.length*.99)]??null,max:sortedGaps.at(-1)??null,over50ms:gaps.filter(v=>v>50).length,over100ms:gaps.filter(v=>v>100).length,longAnimationFrames:globalThis.__baselineLoad.longAnimationFrames};
      return {
        navigation: n && {startTime:n.startTime,domContentLoaded:n.domContentLoadedEventEnd,loadEventEnd:n.loadEventEnd,responseEnd:n.responseEnd,transferSize:n.transferSize,encodedBodySize:n.encodedBodySize},
        paints,
        stages: {readyAt:__baselineLoad.readyAt,hostilesAt:__baselineLoad.hostilesAt,firstAshenAt:__baselineLoad.firstAshenAt,firstGpuFrameAt:__baselineLoad.firstGpuFrameAt},
        startupFrameSpikes: spikes,
        ashen: {presentMs:a.presentMs,loadMs:a.loadMs,ready:a.ready,hostilesReady:a.hostilesReady,gpuFrames:a.gpu?.frames,renderLoopRunning:a.renderLoop?.running},
        resources: {count:resources.length,transferSize:sum('transferSize'),encodedBodySize:sum('encodedBodySize'),decodedBodySize:sum('decodedBodySize'),bundleUrls:resources.filter(r=>/ashenReach-[^/]+\.js/.test(r.name)).map(r=>r.name),longest:resources.map(r=>({name:r.name,initiatorType:r.initiatorType,startTime:r.startTime,duration:r.duration,transferSize:r.transferSize,encodedBodySize:r.encodedBodySize})).sort((a,b)=>b.duration-a.duration).slice(0,20)},
        webgpu: !!navigator.gpu, viewport:{innerWidth,innerHeight,devicePixelRatio},
        canvas:[...document.querySelectorAll('canvas')].map(c=>({width:c.width,height:c.height,clientWidth:c.clientWidth,clientHeight:c.clientHeight})),
      };
    });
    const run = {label,startedAt,...inPage,errors,failedRequests,httpErrors};
    runs.push(run);
    console.log(JSON.stringify({label,paint:inPage.paints,stages:inPage.stages,ashen:inPage.ashen,spikes:{p99:inPage.startupFrameSpikes.p99,max:inPage.startupFrameSpikes.max,over50ms:inPage.startupFrameSpikes.over50ms,longAnimationFrames:inPage.startupFrameSpikes.longAnimationFrames.length},resourceCount:inPage.resources.count,errors:errors.length,failedRequests:failedRequests.length,httpErrors:httpErrors.length}));
    page.off('pageerror',onPageError);
    page.off('console',onConsole);
    page.off('requestfailed',onRequestFailed);
    page.off('response',onResponse);
  }
  const report = {recordedAt:new Date().toISOString(),hostname:os.hostname(),platform:os.platform(),arch:os.arch(),cpus:os.cpus().map(c=>c.model).filter((v,i,a)=>a.indexOf(v)===i),browserVersion:version,cdp,url,viewport:{width:1280,height:720,deviceScaleFactor:1},conditions:'Chrome headless WebGPU; same context; browser cache cleared before cold run, then two same-context warm navigations; no FPS benchmark running; Vite dev server if loopback URL, live CDN if HTTPS URL',runs};
  await fs.writeFile(new URL(reportName,import.meta.url),JSON.stringify(report,null,2)+'\n');
} finally {
  await session.detach().catch(()=>{});
  await context.close().catch(()=>{});
  await browser.close().catch(()=>{});
}
