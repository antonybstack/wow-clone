import { chromium } from 'playwright';
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { captureSurface, appendFrame, writeCaptureManifest } from '../../../../../scripts/lib/capture-manifest.mjs';

const dir = new URL('.', import.meta.url);
const port = process.env.ASHEN_CDP_PORT || '10437';
const url = process.env.ASHEN_URL || 'http://127.0.0.1:6273/ashen-reach.html?play&clean';
const browser = await chromium.connectOverCDP(`http://127.0.0.1:${port}`);
const context = browser.contexts()[0];
const page = context.pages().find(p => p.url().includes('ashen-reach.html')) || await context.newPage();
const errors = [];
page.on('pageerror', e => errors.push({kind:'pageerror', message:e.message}));
page.on('console', m => { if (m.type() === 'error') errors.push({kind:'console', message:m.text()}); });
const shots = [
  {id:'churchyard', x:0, z:8, yaw:0, pitch:.04, distance:3.5},
  {id:'town-plaza', x:0, z:130, yaw:0, pitch:.12, distance:4.5},
  {id:'bridge-approach', x:0, z:190, yaw:0, pitch:-.10, distance:4},
  {id:'cathedral-silhouette', x:0, z:249, yaw:0, pitch:-.10, distance:4, routeFloor:true},
  {id:'cathedral-approach', x:0, z:280, yaw:0, pitch:-.16, distance:4, routeFloor:true},
  {id:'cathedral-nave', x:0, z:335, yaw:0, pitch:-.10, distance:3.5, cathedralFloor:true},
  {id:'forest-performance-route', x:130, z:-50, yaw:0, pitch:-.16, distance:4},
  {id:'woodland-detail', x:72, z:190, yaw:0, pitch:-.16, distance:4},
];
const report = {url, cdpPort:port, viewport:{width:1280,height:720}, shots:[], errors, video:null};
let cdp;
let manifest;
let captureError;
const writes=[];
try {
  await page.setViewportSize(report.viewport);
  await page.bringToFront();
  await page.goto(url, {waitUntil:'commit'});
  await page.waitForFunction(() => window.ASHEN?.ready && ASHEN.hostilesReady, null, {timeout:120000});
  await page.waitForTimeout(800);
  report.initial = await page.evaluate(() => ({
    version: ASHEN.version ?? null,
    viewport: {width: innerWidth, height: innerHeight},
    canvas: {width: document.querySelector('canvas').width, height: document.querySelector('canvas').height},
    enemies: ASHEN.combat.enemies?.length ?? null,
    devicePixelRatio,
    physics: ASHEN.player.getDebugState().usingPhysics,
  }));
  for (const shot of shots) {
    await page.evaluate(s => {
      const a=ASHEN;
      const y=s.cathedralFloor ? a.world.cathedral.floorY : s.routeFloor ? a.world.cathedral.route.heightAt(s.z) : a.world.groundHeight(s.x,s.z);
      a.player.setFlying(false);
      a.player.setWorldPos(s.x,y+1.7,s.z);
      a.player.setFacing(s.yaw);
      a.rig.yaw=s.yaw;
      a.rig.pitch=s.pitch;
      a.rig.distance=a.rig.distanceTarget=s.distance;
    }, shot);
    await page.waitForTimeout(900);
    const pose=await page.evaluate(() => ({
      player:{x:ASHEN.player.body.position.x,y:ASHEN.player.body.position.y,z:ASHEN.player.body.position.z},
      camera:{x:ASHEN.rig.yaw,pitch:ASHEN.rig.pitch,distance:ASHEN.rig.distance},
      physics:ASHEN.player.getDebugState().usingPhysics,
      recoveries:ASHEN.player.getDebugState().recoveries,
      woodlandState:ASHEN.world.woodland.state,
    }));
    await page.screenshot({path:new URL(`${shot.id}.png`,dir).pathname});
    report.shots.push({shot, pose, file:`${shot.id}.png`});
  }

  const start={x:0,z:249};
  await page.evaluate(({x,z}) => {
    const a=ASHEN,y=a.world.cathedral.route.heightAt(z);
    a.player.setWorldPos(x,y+1.7,z);
    a.player.setFacing(0);
    a.rig.yaw=0;a.rig.pitch=-.14;a.rig.distance=a.rig.distanceTarget=4;
  }, start);
  await page.waitForTimeout(600);
  const before=await page.evaluate(() => ({x:ASHEN.player.body.position.x,z:ASHEN.player.body.position.z,recoveries:ASHEN.player.getDebugState().recoveries}));
  await fs.mkdir(new URL('frames/',dir),{recursive:true});
  manifest={version:1,...await captureSurface(page),frames:[]};
  cdp=await context.newCDPSession(page);
  cdp.on('Page.screencastFrame',e => {
    cdp.send('Page.screencastFrameAck',{sessionId:e.sessionId}).catch(()=>{});
    if (captureError) return;
    try {
      const bytes=Buffer.from(e.data,'base64');
      const name=`frame-${String(manifest.frames.length).padStart(5,'0')}.jpg`;
      if (appendFrame(manifest,{name,timestamp:e.metadata.timestamp,bytes}) !== false)
        writes.push(fs.writeFile(new URL(`frames/${name}`,dir),bytes).catch(err=>captureError=err));
    } catch(err) { captureError=err; }
  });
  await cdp.send('Page.startScreencast',{format:'jpeg',quality:87,maxWidth:1280,maxHeight:720,everyNthFrame:1});
  await page.keyboard.down('KeyW');
  await page.waitForTimeout(11000);
  await page.keyboard.up('KeyW');
  await page.waitForTimeout(350);
  await cdp.send('Page.stopScreencast');
  cdp.removeAllListeners('Page.screencastFrame');
  await Promise.all(writes);
  if (captureError) throw captureError;
  await writeCaptureManifest(dir.pathname,manifest,await captureSurface(page));
  const after=await page.evaluate(() => ({x:ASHEN.player.body.position.x,z:ASHEN.player.body.position.z,recoveries:ASHEN.player.getDebugState().recoveries,physics:ASHEN.player.getDebugState().usingPhysics}));
  assert(after.z>before.z+2);
  assert.equal(after.recoveries,before.recoveries);
  assert(after.physics);
  report.video={before,after,frames:manifest.frames.length};
  const mobileContext=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,deviceScaleFactor:3});
  try {
    const mobilePage=await mobileContext.newPage();
    mobilePage.on('pageerror', e => errors.push({kind:'mobile-pageerror',message:e.message}));
    mobilePage.on('console', m => {if(m.type()==='error') errors.push({kind:'mobile-console',message:m.text()});});
    await mobilePage.goto(url,{waitUntil:'commit'});
    await mobilePage.waitForFunction(() => window.ASHEN?.ready && ASHEN.hostilesReady,null,{timeout:120000});
    await mobilePage.waitForTimeout(900);
    report.mobile={kind:'desktop Chromium mobile emulation',surface:await captureSurface(mobilePage),physics:await mobilePage.evaluate(()=>ASHEN.player.getDebugState().usingPhysics),file:'mobile-portrait.png'};
    await mobilePage.screenshot({path:new URL('mobile-portrait.png',dir).pathname});
  } finally {
    await mobileContext.close();
  }
  report.passed=errors.length===0;
  await fs.writeFile(new URL('report.json',dir),JSON.stringify(report,null,2));
} finally {
  await page.keyboard.up('KeyW').catch(()=>{});
  if(cdp) await cdp.send('Page.stopScreencast').catch(()=>{});
  await Promise.all(writes);
  await fs.writeFile(new URL('report.json',dir),JSON.stringify(report,null,2));
  await browser.close();
}
console.log(JSON.stringify({shots:report.shots.length,video:report.video,errors:report.errors,initial:report.initial},null,2));
